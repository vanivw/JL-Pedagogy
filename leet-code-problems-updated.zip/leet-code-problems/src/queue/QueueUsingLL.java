package queue;

import java.util.NoSuchElementException;

public class QueueUsingLL {

    private ListNode front;

    private ListNode rear;
    private int length;

    public QueueUsingLL(){
        front =null;
        rear = null;
        length=0;
    }

    private class ListNode{
        private int data;
        private ListNode next;

     public ListNode(int data){
         this.data = data;
     }
    }

    public int length(){
        return length;
    }

    public void enqueue(int data){
        ListNode temp = new ListNode(data);
        if(isEmpty()){
            front = temp;
        }else{
            rear.next = temp;
        }
        rear= temp;
        length++;
    }

    public int dequeue(){
        if(isEmpty()){
            throw new NoSuchElementException("Queue is empty");
        }
        int result= front.data;
        front = front.next;
        if(front == null){
            rear=null;
        }
        length--;
        return result;
    }

    public int first(){
        if(isEmpty()){
            throw new NoSuchElementException("Queue is empty");
        }
        return front.data;
    }

    public int last(){
        if(isEmpty()){
            throw new NoSuchElementException("Queue is empty");
        }
        return rear.data;
    }
    public void print(){
        if(isEmpty()){
            return;
        }
        ListNode current= front;
        while(current!=null){
            System.out.print(current.data + "-->");
            current = current.next;
        }
        System.out.println("null");
    }
    public boolean isEmpty(){
        return length==0;
    }

    public static void main(String[] args) {
        QueueUsingLL queueUsingLL = new QueueUsingLL();

        queueUsingLL.enqueue(10);
        queueUsingLL.enqueue(20);
        queueUsingLL.enqueue(30);
        queueUsingLL.print();
        System.out.println("First elemet "+ queueUsingLL.first());
        System.out.println("Last elemet "+ queueUsingLL.last());
        System.out.println("Before deleting");
        queueUsingLL.dequeue();
        queueUsingLL.dequeue();
        System.out.println("after deleting");
        queueUsingLL.print();



    }
}
