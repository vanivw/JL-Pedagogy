package integer;

/*
Given a signed 32-bit integer x, return x with its digits reversed. If reversing x causes the value to go outside the signed 32-bit integer range [-231, 231 - 1], then return 0.

Assume the environment does not allow you to store 64-bit integers (signed or unsigned).



Example 1:

Input: x = 123
Output: 321
 */
public class ReverseInteger {
    public static void main(String[] args) {
 System.out.println("Reverse integer:"+ reverse(121));
    }

    public static int reverse(int x) {
        int num =x;
        int rev =0;
        while(num!=0){
            rev = (rev*10) + (num%10);
            num = num/10;
        }
        if(rev < Integer.MIN_VALUE || rev > Integer.MAX_VALUE){
            return 0;
        }else {
            return rev;
        }
    }
}
