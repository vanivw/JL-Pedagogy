package integer;

import java.util.ArrayList;
import java.util.List;

/*
Given an integer n, return a string array answer (1-indexed) where:

answer[i] == "FizzBuzz" if i is divisible by 3 and 5.
answer[i] == "Fizz" if i is divisible by 3.
answer[i] == "Buzz" if i is divisible by 5.
answer[i] == i (as a string) if none of the above conditions are true.
 */
public class FizzBuzz {
    public static void main(String[] args) {
        int n=3;
        List<String> res = fizzBuzz(15);
        System.out.println("Result: "+res);

    }
    public static List<String> fizzBuzz(int n) {
        List<String> list = new ArrayList<>();
        for(int i=1;i<=n;i++) {
            if (i % 3 == 0) {
            list.add("FIZZ");
            } else if(i%5 ==0){
                list.add("BUZZ");
            }else if(i%3 ==0 && i%5 ==0){
                list.add("FIZZBUZZ");
            }else{
                list.add(String.valueOf(i));
            }
        }
        return list;
    }
}
