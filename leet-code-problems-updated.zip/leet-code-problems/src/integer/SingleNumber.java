package integer;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/*
Given a non-empty array of integers nums, every element appears twice except for one. Find that single one.

You must implement a solution with a linear runtime complexity and use only constant extra space.
 */
public class SingleNumber {
    public static void main(String[] args) {
        int [] nums = {2,2,1};
System.out.println("Result:" + singleNumber(nums));

    }
    public static int singleNumber(int[] nums) {
   Set<Integer> set = new HashSet<>();
        for(int n: nums){
            if(set.contains(n)){
                set.remove(n);
            }else{
                set.add(n);
            }
        }

        Iterator it = set.iterator();
       return (int) it.next();
    }
}
