package sorting;

import java.util.Arrays;

public class BubbleSort {
    public static void main(String[] args) {
        int [] nums={3,1,5,2,6,4};
        System.out.println("Sorted: "+ Arrays.toString(sortArray(nums)));

    }

    public static  int[] sortArray(int[] nums) {

        int n= nums.length;
        boolean isSwapped=false;
        for (int i=0;i<n;i++){
            for(int j=0;j<n-i-1;j++){
                if(nums[j] > nums[j+1] ){
                    int temp = nums[j];
                    nums[j]=nums[j+1];
                    nums[j+1] = temp;
                    isSwapped = true;
                }
            }
            if(!isSwapped){
                break;
            }
        }
        return nums;

    }
}
