package dynamicprogramming;

/*
You are given an integer array coins representing coins of different denominations and an integer amount representing a total amount of money.

Return the fewest number of coins that you need to make up that amount. If that amount of money cannot be made up by any combination of the coins, return -1.

You may assume that you have an infinite number of each kind of coin.
 */
public class CoinChange {
    public static void main(String[] args) {
        int []coins={1,2,5};
        System.out.println("Min coins--" +coinChange(coins,11));

    }

    /*
    Time complexity---O(m*n)
     */
    public static int coinChange(int[] coins, int amount) {

        if(amount<0){
            return 0;
        }
int [] minCoinsDP = new int[amount+1];

        for(int i=1;i<= amount;i++){
            minCoinsDP[i] = Integer.MAX_VALUE;

            for(int coin: coins){
                if(coin<= i && minCoinsDP[i-coin] != Integer.MAX_VALUE ){
                    minCoinsDP[i] = Math.min(minCoinsDP[i],1+minCoinsDP[i-coin]);
                }
            }
        }
 if(minCoinsDP[amount] == Integer.MAX_VALUE){
     return -1;
 }
 return minCoinsDP[amount];
    }
}
