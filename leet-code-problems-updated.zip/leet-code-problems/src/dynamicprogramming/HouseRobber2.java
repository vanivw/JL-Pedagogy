package dynamicprogramming;

public class HouseRobber2 {

    public static void main(String[] args) {
        int [] nums={2,7,3,1,4,2,1,8};
        System.out.println("House Robber2 example:" +rob(nums));


    }

    public static int  rob(int[] nums) {
        if(nums.length<2){
        return nums[0];
        }
        int [] skipLastElement = new int[nums.length-1];
        int [] skipFirstElement = new int[nums.length-1];

        for (int i = 0; i <nums.length-1 ; i++) {
            skipLastElement[i] = nums[i];
            skipFirstElement[i] = nums[i+1];
        }

        int lootSkippingLast = robHelper(skipLastElement);
        int lootSkippingFirst = robHelper(skipFirstElement);

        return Math.max(lootSkippingLast,lootSkippingFirst);
    }

    public static int robHelper(int[] nums) {

        if(nums.length < 2){
            return nums[0];
        }

        int [] dp = new int[nums.length];
        dp[0] = nums[0];
        dp[1] = Math.max(nums[0],nums[1]);

        for(int i=2;i<nums.length;i++){
            dp[i] = Math.max(dp[i-2] + nums[i], dp[i-1]);
        }
        return dp[nums.length-1];

    }

}
