package dynamicprogramming;

public class JumpGame {
    public static void main(String[] args) {
        int [] nums={1,1,2,5,2,1,0,0,1,3};
        System.out.println("Result:---" + canJump(nums));

    }
    public static boolean canJump(int[] nums) {

        int final_pos= nums.length-1;

        for(int i=nums.length -2;i>=0;i--){
            if(i+nums[i] >= final_pos){
                final_pos =i;
            }
        }
        return final_pos==0;

    }
}
