package graph;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class GraphUsingLL {
    private LinkedList<Integer>[] adj;
    private int V;
    private int E;

    public GraphUsingLL(int nodes){
        this.V=nodes;
        this.E=0;
        this.adj = new LinkedList[nodes];
        for(int i=0;i<V;i++){
            adj[i] = new LinkedList<>();
        }

    }

    public void addEdge(int u,int v){
       this.adj[u].add(v);
       this.adj[v].add(u);
        E++;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(V+ "vertices, " + E+ " edges " +"\n");
        for(int v=0;v<V;v++){
            sb.append(v+": ");
            for(int w:adj[v]){
                sb.append(w+" ");
            }
            sb.append("\n");

        }
        return sb.toString();
    }

    public void bfs(int s){
        boolean []visited = new boolean[V];
        Queue<Integer> queue = new LinkedList<>();
        visited[s] =true;
        queue.offer(s);
        while(!queue.isEmpty()){
            int u = queue.poll();
            System.out.println(u + " ");
            for(int v:adj[u]){
                if(!visited[v]){
                    visited[v]=true;
                    queue.offer(v);
                }
            }
        }
    }

    public void dfs(int s)
    {
        boolean [] visited = new boolean[V];
        Stack<Integer> st = new Stack<Integer>();
        st.push(s);
        while(!st.isEmpty()){
            int u = st.pop();
            if(!visited[u]){
                visited[u]=true;
                //System.out.println("DFS---");
                System.out.println(u +" ");
                for(int v:adj[u]){
                    if(!visited[v]){
                        st.push(v);
                    }
                }
            }

        }


    }
    public static void main(String[] args) {
        GraphUsingLL g = new GraphUsingLL(5);
        g.addEdge(0,1);
        g.addEdge(1,2);
        g.addEdge(2,3);
        g.addEdge(3,0);
        g.addEdge(2,4);
        System.out.println("Before bfs:---"+g);
        g.bfs(0);
        System.out.println("Dfs:---");
        g.dfs(0);

    }
}
