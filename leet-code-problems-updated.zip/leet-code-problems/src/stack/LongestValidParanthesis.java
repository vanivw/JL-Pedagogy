package stack;

import java.util.Stack;

/*
Given a string containing just the characters '(' and ')', return the length of the longest valid (well-formed) parentheses
substring
.



Example 1:

Input: s = "(()"
Output: 2
Explanation: The longest valid parentheses substring is "()".
Example 2:

Input: s = ")()())"
Output: 4
Explanation: The longest valid parentheses substring is "()()".
Example 3:

Input: s = ""
Output: 0


Constraints:

0 <= s.length <= 3 * 104
s[i] is '(', or ')'.
 */
public class LongestValidParanthesis {
    public static void main(String[] args) {
        String s= ")()())";
        System.out.println("Longest valid parantheses "+ longestValidParentheses(s));

    }
    public static int longestValidParentheses(String s) {
        int maxlen=0;
        Stack<Integer> stack = new Stack<>();
        stack.push(-1);
       for(int i=0;i<s.length();i++){
           if(s.charAt(i) == '('){
               stack.push(i);
           }else{
               stack.pop();
               if(stack.isEmpty()){
                   stack.push(i);
               }else{
                   maxlen= Math.max(maxlen,i-stack.peek());
               }
           }

       }
        return maxlen;
    }
}
