package arrays;

import java.util.PriorityQueue;

public class KthLargestElement {
    public static void main(String[] args) {
        int [] nums ={3,2,1,5,6,4};
        int k=2;
        System.out.println("Kth largest element:  " +findKthLargest(nums,k));

    }

    public static int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for(int n: nums){
            minHeap.add(n);

            if(minHeap.size()>k){
                minHeap.poll();
            }
        }

return minHeap.peek();
    }
}
