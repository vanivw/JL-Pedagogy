package arrays;


import java.util.Arrays;

public class PrimeNumberRange {
    public static void main(String[] args) {
        System.out.println("Primenumbers---"+ countPrimes(10));

    }
    public static int countPrimes(int n) {
        boolean[] primes = new boolean[n];
        Arrays.fill(primes, true);
        int result = 0;
        for (int i = 2; i < n; ++i) {
            if (primes[i]) {
                result++;
                for (int j = i + i; j < n; j += i) {
                    primes[j] = false;
                }
            }
        }
        return result;
    }
}
