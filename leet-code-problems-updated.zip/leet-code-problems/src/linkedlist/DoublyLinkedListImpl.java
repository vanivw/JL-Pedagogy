package linkedlist;

import java.util.NoSuchElementException;

public class DoublyLinkedListImpl {
    private ListNode head;
    private ListNode tail;
    private int length;
    public DoublyLinkedListImpl(){
        this.head=null;
        this.tail=null;
        this.length=0;
    }


    public boolean isEmpty(){
        return length == 0;
    }

    public int getLength(){
        return length;
    }

    public void printForward(){
        if(head==null){
            return;
        }
        ListNode temp=head;
        while(temp!=null){
            System.out.print(temp.data+"-->");
            temp=temp.next;
        }
        System.out.println("null");
        System.out.print(" ");
    }

    public void printBackward(){
        if(tail==null){
            return;
        }
        ListNode temp=tail;
        while(temp!=null){
            System.out.print(temp.data+"-->");
            temp=temp.previous;
        }
        System.out.println("null");
        System.out.print(" ");
    }

    public void insertFirst(int data){
        ListNode newNode = new ListNode(data);
        if(isEmpty()){
            tail=newNode;
        }else{
            head.previous = newNode;
        }
        newNode.next=head;
        head=newNode;
        length++;
    }

    public void insertLast(int data){
        ListNode newNode = new ListNode(data);
        if(isEmpty()){
            head=newNode;
        }else{
            tail.next=newNode;
            newNode.previous = tail;
        }
        tail=newNode;
        length++;
    }

    public ListNode deleteFirst(){
        if(isEmpty()){
            throw new NoSuchElementException("List is empty");
        }
        ListNode temp=head;
        if(head==tail){
            tail=null;
        }else{
            head.next.previous=null;
        }
        head=head.next;
        temp.next=null;
        length--;
        return temp;
    }

    public ListNode deleteLast(){
        if(isEmpty()){
            throw new NoSuchElementException("List is empty");
        }
        ListNode temp=tail;
        if(head==tail){
            head=null;
        }else{
            tail.previous.next=null;
        }
        tail = tail.previous;
        temp.previous=null;
        length--;
        return temp;
    }
    public static void main(String[] args) {
        DoublyLinkedListImpl dll = new DoublyLinkedListImpl();
        dll.insertFirst(1);
        dll.insertFirst(10);
        dll.insertFirst(20);
        System.out.println("Insert first");
        dll.printForward();
        // dll.printBackward();
        System.out.println("Delete first");
        dll.deleteFirst();
        dll.printForward();
        DoublyLinkedListImpl dll2 = new DoublyLinkedListImpl();
        dll2.insertLast(10);
        dll2.insertLast(20);
        dll2.insertLast(30);
        dll2.insertLast(40);
        System.out.println("Insert last");
        dll2.printForward();
        //dll2.printBackward();
        System.out.println("Delete Last");
        dll2.deleteLast();
        dll2.printForward();
    }
    private class ListNode{
        private int data;
        private ListNode next;
        private ListNode previous;
       public   ListNode(int data){
           this.data = data;
       }
    }
}
