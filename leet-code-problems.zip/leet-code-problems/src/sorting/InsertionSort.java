package sorting;

import java.util.Arrays;

public class InsertionSort {
    public static void main(String[] args) {
        int [] nums={5,1,9,2,10};
        System.out.println("Insertion sort--" + Arrays.toString(sortArray(nums)));

    }

    public static  int[] sortArray(int[] nums) {
        int n =nums.length;
        for(int i=1;i<n;i++){
            int temp = nums[i];
            int j= i-1;
            while(j>=0 && nums[j]>temp){
                nums[j+1] = nums[j];
                j=j-1;
            }
            nums[j+1]=temp;

        }
        return nums;
    }
}
