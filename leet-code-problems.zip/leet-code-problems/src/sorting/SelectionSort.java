package sorting;

import java.util.Arrays;

public class SelectionSort {
    public static void main(String[] args) {
        int [] nums={3,1,5,2,6,4};
        System.out.println("Sorted: "+ Arrays.toString(sortArray(nums)));

    }
    public static  int[] sortArray(int[] nums) {
        int n = nums.length;
        for(int i=0;i<n-1;i++ ){
            int min=i;
            for(int j=i+1;j<n;j++){
                if(nums[j]< nums[min]){
                        min =j;
                }

            }
            int temp = nums[min];
            nums[min] = nums[i];
            nums[i]=temp;
        }
    return nums;
    }
}
