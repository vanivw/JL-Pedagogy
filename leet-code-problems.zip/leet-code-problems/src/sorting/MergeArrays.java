package sorting;

import java.util.Arrays;

public class MergeArrays {
    public static void main(String[] args) {
        int[] a={1,2,3,5,10};
        int[] b={4,6,11,15};
        int []res = merge(a,b);
        System.out.println("Merged Arrays:--"+ Arrays.toString(res));

    }

    public static int[] merge(int []a, int []b){
        int m=a.length;
        int n= b.length;
        int i=0,j=0,k=0;
        int []res = new int[m+n];

        while(i<m && j<n){
            if(a[i]<b[j]){
                res[k]=a[i];
                i++;
            }else{
                res[k]=b[j];
                j++;
            }
            k++;
        }

        while(i<m){
            res[k] =a[i];
            i++;
            k++;
        }

        while(j<n){
            res[k] = b[j];
            j++;
            k++;

        }
        return res;
    }
}
