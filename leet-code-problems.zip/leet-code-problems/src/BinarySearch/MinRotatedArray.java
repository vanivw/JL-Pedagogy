package BinarySearch;

public class MinRotatedArray {
    public static void main(String[] args) {
        int [] nums={11,13,15,17};
        System.out.println("Minimum element in rotated array is:"+findMin(nums));

    }
    public static int findMin(int[] nums) {
        int low=0,high=nums.length-1;
        int ans=Integer.MAX_VALUE;

        while(low<=high){
            int mid = (low+high)/2;

            if(nums[low]<=nums[mid]){
                ans =Math.min(ans,nums[low]);
                low=mid+1;
            }else{
                ans =Math.min(ans,nums[high]);
                high=mid-1;
            }
        }
return ans;
    }
}
