package BinarySearch;

import java.util.Arrays;

public class ClosestNumber {

    public static void main(String[] args) {
        int arr[] = {1, 2, 4, 5, 6, 6, 8, 8, 9 };
        int target = 11;
       // Arrays.sort(arr);
        System.out.println("Closest number-->"+findClosest(arr, target));
        System.out.println("Closest number using geeks-->"+findClosestGeeks(arr, target));
    }


    public static int findClosest(int arr[], int target)
    {
        int n = arr.length-1;

        // Doing binary search
        int low = 0, high = n, mid = 0;
        while (high-low>1) {
            mid = (low + high) / 2;
            if(arr[mid]<target){
                low=mid;
            }else{
                high=mid;
            }

        }
        if(target-arr[low] <= arr[high] - target){
            return arr[low];
        }
        // Only single element left after search
        return arr[high];
    }

    public static int findClosestGeeks(int[] arr,
                                  int target)
    {
        int left = 0, right = arr.length - 1;
        while (left < right) {
            if (Math.abs(arr[left] - target)
                    <= Math.abs(arr[right] - target)) {
                right--;
            }
            else {
                left++;
            }
        }
        return arr[left];
    }


}
