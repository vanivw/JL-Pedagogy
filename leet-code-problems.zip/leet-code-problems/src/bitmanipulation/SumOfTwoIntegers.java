package bitmanipulation;

public class SumOfTwoIntegers {
    public static void main(String[] args) {
        int sum = getSum(4,5);
        System.out.println("Sum----" + sum);

    }
    public static int getSum(int a, int b) {
        while(b!=0){
            int carry = (a & b) << 1;
            a = a ^ b;
            b= carry;

        }
return a;
    }
}
