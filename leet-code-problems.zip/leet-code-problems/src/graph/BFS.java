package graph;

public class BFS {

    public static void main(String[] args) {

    }
}
