package graph;

import java.util.LinkedList;
import java.util.Queue;

public class BarpartiteGraph {
    public static void main(String[] args) {
        int [][] graph = {{1,2,3},{0,2},{0,1,3}, {0,2}};
        System.out.println("Is graph barptite: " + isBipartite(graph));

    }
    public static boolean isBipartite(int[][] graph) {
        int n= graph.length;
        boolean ans = helper(graph,n);
        return ans;

    }

    private static  boolean helper(int[][] graph, int n) {
        int color[] = new int[n];
        for(int i=0;i<n;i++){
            color[i] = -1;
        }
        for(int i=0;i<n;i++){
            if(color[i] == -1){
                Queue<Integer> qu = new LinkedList<>();
                qu.add(i);
                color[i] =0;

                while(!qu.isEmpty()){
                    int curr = qu.remove();
                    for(int j=0;j<graph[curr].length;j++){
                        int dest = graph[curr][j];

                        if(color[dest] == -1){
                            color[dest] = 1-color[j];
                            qu.add(dest);
                        }else if(color[dest] == color[curr]){
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }
}
