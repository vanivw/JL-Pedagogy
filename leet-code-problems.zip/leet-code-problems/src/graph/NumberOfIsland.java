package graph;

import java.util.LinkedList;
import java.util.Queue;

public class NumberOfIsland {

    public static void main(String[] args) {
 char [][] grid  = {
         {'1','1','1','1','0'},
         {'1','1','0','1','0'},
         {'1','1','0','0','0'},
         {'0','0','0','0','0'}
};
 System.out.println("Number of island---" + numIslands(grid));
    }

    public static int numIslands(char[][] grid) {
        if(grid==null || grid.length ==0){
            return 0;
        }

        int count=0;
        int row= grid.length;
        int col = grid[0].length;

        int [][] directions ={{1,0}, {0,1}, {-1,0}, {0,-1}};// move in four directions
        Queue<int[]> qu = new LinkedList<>();
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                if(grid[i][j] == '1')
                    count++;// incrementing the count
                qu.add(new int[] {i,j});
                grid[i][j] ='2';// marking as visited

                while(!qu.isEmpty()){
                    int [] curr = qu.poll();// removing from queue

                    for(int [] dir:directions){
                        int r= curr[0] + dir[0];
                        int c= curr[1] + dir[1];

                        if(r>=0 && r<row && c>=0 && c<col && grid[r][c] == '1') {
                            qu.add(new int[]{r, c});
                            grid[r][c] = '2';
                        }

                    }
                }


            }
        }
return count;
    }


}
