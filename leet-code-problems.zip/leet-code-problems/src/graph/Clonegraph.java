package graph;

import java.util.*;
import java.util.stream.Collectors;

public class Clonegraph {

    public static void main(String[] args) {
        Node node1 = new Node(1);
        Node node2 = new Node(2);
        Node node3 = new Node(3);
        Node node4 = new Node(4);
        List<Node> list = new ArrayList<>();
        list.add(node2);
        list.add(node4);
        node1.neighbors = list;
        list = new ArrayList<>();
        list.add(node1);
        list.add(node3);
        node2.neighbors = list;
        list = new ArrayList<>();
        list.add(node2);
        list.add(node4);
        node3.neighbors = list;
        list = new ArrayList<>();
        list.add(node1);
        list.add(node3);
        node4.neighbors = list;
        Node n = cloneGraph(node1);
        System.out.println("Result---" + n.val);
        Node dfsnode = cloneGraphDFS(node1);
        System.out.println("Result using bfs---" + n.val);
       // System.out.println("Result using dfs neighbours---" + dfsnode.neighbors.get(0).val);
        for (int i = 0; i < n.neighbors.size(); i++) {
            System.out.println("Result using bfs---" + n.neighbors.get(i).val);
        }
    }
    public static Node cloneGraph(Node node) {

        if(node == null)
            return null;

        Queue<Node> q = new LinkedList<>();
        q.add(node);
        Map<Node,Node> map = new HashMap<>();
        map.put(node, new Node(node.val));
        while(!q.isEmpty()){
            Node cur = q.poll();
            for(Node ng :cur.neighbors){
                if(!map.containsKey(ng)){
                    map.put(ng, new Node(ng.val));
                    q.add(ng);
                }
                map.get(cur).neighbors.add(map.get(ng));
            }
        }
        for(Map.Entry<Node, Node>entry: map.entrySet()){
          //  System.out.println("Key key--" + entry.getKey().val);
         Node val = entry.getValue();
            System.out.println("value Key--" + val.val);
         for(int i=0;i<val.neighbors.size();i++){
             System.out.println("Node val--" + val.neighbors.get(i).val);
         }
        }

return map.get(node);
    }

    public static Node cloneGraphDFS(Node node) {
        if(node == null)
            return null;

        HashMap<Node, Node> hm = new HashMap<Node, Node>();
       if(hm.containsKey(node)){
           return hm.get(node);
       }
       Node newNode = new Node(node.val);
       hm.put(node,newNode);
       for(Node ng:node.neighbors){
           newNode.neighbors.add(cloneGraphDFS(ng));
       }
        return newNode;
    }

    private static  class Node {
        public int val;
        public List<Node> neighbors;
        public Node() {
            val = 0;
            neighbors = new ArrayList<Node>();
        }
        public Node(int _val) {
            val = _val;
            neighbors = new ArrayList<Node>();
        }
        public Node(int _val, ArrayList<Node> _neighbors) {
            val = _val;
            neighbors = _neighbors;
        }


    }
}




