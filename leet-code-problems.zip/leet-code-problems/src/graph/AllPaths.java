package graph;

import java.util.ArrayList;
import java.util.List;

public class AllPaths {
    public static void main(String[] args) {
        int [][] graph = {{1,2},{3},{3},{}};
        System.out.println("Path from source to target--- " + allPathsSourceTarget(graph));

    }
    public static List<List<Integer>> allPathsSourceTarget(int[][] graph) {
        List<List<Integer>> ans = new ArrayList<>();
        findPath(0,graph,new ArrayList<>(),ans);
        return ans;

    }

    public static void findPath(int node, int [][] graph, List<Integer> curr, List<List<Integer>> ans){
        curr.add(node);
        if(node == graph.length -1){
            ans.add(new ArrayList<>(curr));
            curr.remove(curr.size()-1);
            return;
        }

        for(int g: graph[node]){
            findPath(g,graph,curr,ans);
        }
        curr.remove(curr.size()-1);
    }
}

