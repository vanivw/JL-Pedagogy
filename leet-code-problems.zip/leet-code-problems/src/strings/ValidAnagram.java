package strings;

import java.util.Arrays;

public class ValidAnagram {
    public static void main(String[] args) {
        String s = "anagram", t = "nagaramy";
        System.out.println("Anagram:"+isAnagram(s,t));

    }
    public static boolean isAnagram(String s, String t) {

        String st1 = s.trim();
        String st2=t.trim();

        if(st1.length()== st2.length()){

            char []s1 = st1.toCharArray();

            char []s2 = st2.toCharArray();

            Arrays.sort(s1);
            Arrays.sort(s2);
           return Arrays.equals(s1,s2);
        }

        return false;
    }
}
