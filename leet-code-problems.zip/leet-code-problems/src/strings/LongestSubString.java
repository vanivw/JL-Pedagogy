package strings;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LongestSubString {
    public static void main(String[] args) {
        int lnth=lengthOfLongestSubstring3("pwwkew");
        System.out.println("Length of Substring"+lnth);

    }
    public static int lengthOfLongestSubstring(String s) {
        char[] ch =s.toCharArray();
        Map<Character,Integer> hm=new HashMap<>();
        int count=0;
        String substr="";
        for(int i=0;i<ch.length;i++){
            if(!hm.containsKey(ch[i])){
                hm.put(ch[i],i);
            }else{
                hm.clear();
            }
            if(hm.size()>count){
                count=hm.size();
                substr=hm.keySet().toString();
            }
        }


        System.out.println("Substrrlength---"+count);
        System.out.println("Substr"+substr);
        return count;
    }

    public static int lengthOfLongestSubstring2(String s) {
        int n = s.length();
        int maxLength = 0;

        HashMap<Character, Integer> charIndexMap = new HashMap<>();

        int start = 0;
        int end = 0;

        while (end < n) {
            char currentChar = s.charAt(end);

            if (charIndexMap.containsKey(currentChar)) {
                start = Math.max(charIndexMap.get(currentChar) + 1, start);
            }

            charIndexMap.put(currentChar, end);

            maxLength = Math.max(maxLength, end - start + 1);

            end++;
        }



        return maxLength;
    }

    public static int lengthOfLongestSubstring3(String s) {
Set<Character> set = new HashSet<>();
int l=0,r =0, max =0;
while(r < s.length()){
    if(!set.contains(s.charAt(r))){
        set.add(s.charAt(r));
        max = Math.max(max, set.size());
        r++;
    }else{
        set.remove(s.charAt(l));
        l++;
    }
}
return max;


    }
}
