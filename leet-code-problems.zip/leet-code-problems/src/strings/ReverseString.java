package strings;

import java.util.Arrays;

/*
Write a function that reverses a string. The input string is given as an array of characters s.

You must do this by modifying the input array in-place with O(1) extra memory.



Example 1:

Input: s = ["h","e","l","l","o"]
Output: ["o","l","l","e","h"]
Example 2:

Input: s = ["H","a","n","n","a","h"]
Output: ["h","a","n","n","a","H"]
 */
public class ReverseString {
    public static void main(String[] args) {
       char[] s = {'h','a','n','n','a','h'};
        char[] str = {'h','e','l','l','o','h'};
        reverseString(s);
        reverseStringUsingSB(s);
    }
    public static void reverseString(char[] s) {
        String rev="";
        for(int i=s.length-1;i>=0;i--){
            rev = rev+s[i];
        }
        char []revArr = rev.toCharArray();
        System.out.println("Reversed array:"+ Arrays.toString(revArr));

    }

    public static void reverseStringUsingSwap(char[] s) {
        int left=0;
        int right=s.length-1;
        while(left<right){
            char temp =s[left];
            s[left]=s[right];
            s[right] = temp;
            left++;
            right--;
        }

    }

    public static void reverseStringUsingSB(char[] s) {
      StringBuffer sb = new StringBuffer();
      sb.append(s);
      sb.reverse();
      Arrays.toString(sb.chars().toArray());
      System.out.println("Reverse String using string buffer:"+Arrays.toString(sb.toString().toCharArray()));
    }
}
