package strings;

public class StringToInt {
    public static void main(String[] args) {
        System.out.println("String to Int---" + convertStrToInt("123"));

    }

    public static int convertStrToInt(String s){
        int num =0;
        int n=s.length();
        for(int i=0;i<n;i++){
            int no= s.charAt(i);
            num = num*10+ (no-48);
        }
        return num;
    }
}
