package strings;

import java.util.*;
import java.util.stream.Collectors;

public class DuplicateWords {
    public static void main(String[] args) {
        String s ="How is Weather.How is the environment. How was the project";
        duplicateWords(s);
        duplicateWordsUsingFreq(s);
        duplicateWordsUsingSet(s);

    }
    public static void duplicateWords(String inputString){
        String [] words = inputString.toLowerCase().split(" ");
        Map<String, Integer> mapCount = new HashMap<>();
        for(String word: words){
            if(mapCount.containsKey(word)){
                mapCount.put(word, mapCount.get(word)+1);
            }else{
                mapCount.put(word, 1);
            }
        }

        Set<String> counts= mapCount.keySet();

        for(String c :counts){
            if(mapCount.get(c)>1){
                System.out.println(c + " : " +(mapCount.get(c)));
            }
        }
    }

    public static void duplicateWordsUsingFreq(String inputString){
        List<String> wordList = Arrays.stream(inputString.split(" ")).collect(Collectors.toList());
        Map<String, Integer> duplicateWords = new HashMap<>();
        for(String word: wordList){
            duplicateWords.put(word,Collections.frequency(wordList,word));
        }
        //System.out.println("Duplicate words:---" +duplicateWords);
        Map<String, Integer> dupWordsMapWithCount = duplicateWords.entrySet()
                .stream().filter(e -> e.getValue() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        System.out.println("Duplicate words with count:---" +dupWordsMapWithCount);

    }
    public static void duplicateWordsUsingSet(String inputString){
        List<String> wordList = Arrays.stream(inputString.split(" ")).collect(Collectors.toList());

        Set<String> tempSet = new HashSet<>();
       List<String> dupwordList= wordList.stream().filter(w-> !tempSet.add(w)).collect(Collectors.toList());
        System.out.println("Duplicate words without count:---" +dupwordList);
    }

}
