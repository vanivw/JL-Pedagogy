package strings;

public class ReverseWords {
    public static void main(String[] args) {
        String s ="a good   example";
        String str= reverseWords(s);
        System.out.println("Reverse words:"+str);

    }
    public static String reverseWords(String s) {
        String[] words = s.trim().replaceAll(" +", " ").split(" ");
        StringBuffer sb=new StringBuffer(s);
        String revWords="";
        for(int i= words.length-1;i>=0;i--){
            revWords = revWords  + words[i] + " ";
        }
        return revWords;

    }
}
