package strings;

/*
Given a string s, return the longest
palindromic

substring
 in s.



Example 1:

Input: s = "babad"
Output: "bab"
Explanation: "aba" is also a valid answer.
Example 2:

Input: s = "cbbd"
Output: "bb"


Constraints:

1 <= s.length <= 1000
s consist of only digits and English letters.
 */
public class LongestPalindromeSubstring {
    public static void main(String[] args) {

String s="cbbd";
System.out.println("Longest Palindromic substring---"+longestPalindrome(s));
    }
    public static String longestPalindrome(String s) {
        String longestPalindrome="";
        for(int i=0;i<s.length();i++){
            for(int j=i+1;j<s.length();j++){
                String substr= s.substring(i,j);
                if(isPalindrome(substr) && substr.length() >longestPalindrome.length()){
                    longestPalindrome=substr;
                }

            }
        }
return longestPalindrome;
    }

    private static boolean isPalindrome(String s){
        int i=0,j=s.length()-1;
        while(i<j){
            if(s.charAt(i)!=s.charAt(j)){
                return false;
            }
            i++;
            j--;
        }
 return true;
    }
}
