package arrays;

public class SecondLargestElement {
    public static void main(String[] args) {
        int []nums={12, 35, 1, 10, 34, 1 };
        System.out.println("Second largest element: "+ secondLargest(nums));

    }

    public static int secondLargest(int [] nums){
        int first=Integer.MIN_VALUE;
        int second =Integer.MIN_VALUE;

        if(nums.length<2){
            return -1;
        }

        for(int i=0;i<nums.length;i++){
            if(nums[i] > first){
                second = first;
                first = nums[i];
            } else if( nums[i]>second && nums[i]!=first){
                second = nums[i];
            }

        }

        return second;
    }
}
