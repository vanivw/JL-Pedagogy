package arrays;

public class MaxConsecutiveOnes {
    public static void main(String[] args) {
        int [] nums={1,1,0,1,1,1};
        System.out.println("Max consecutive one's :--"+findMaxConsecutiveOnes(nums));
        System.out.println("Max consecutive one's2 :--"+findMaxConsecutiveOnes2(222));

    }
    public static int findMaxConsecutiveOnes(int[] nums) {

        int max=0;
        int count=0;

        for(int i=0;i< nums.length;i++){
            if(nums[i] == 1){
                count++;
                if(count>max){
                    max=count;
                }
            } else if(nums[i] == 0){
                count =0;
            }
        }

return max;
    }

    public static int findMaxConsecutiveOnes2(int num) {

        String binary = Integer.toBinaryString(num);
        int count = 0;
        int maxCount = 0;

        // Loop through the binary string to find the longest consecutive 1s
        for (int i = 0; i < binary.length(); i++) {
            if (binary.charAt(i) == '1') {
                count++;
                if (count > maxCount) {
                    maxCount = count;
                }
            } else {
                count = 0;
            }
        }

        return maxCount;
    }
}
