package arrays;

public class MaximumSubArray {
    public static void main(String[] args) {
int [] nums={-2,1,-3,4,-1,2,1,-5,4};
System.out.println("Maximum Sub array:--- " +maxSubArray2(nums));
    }
    public static int maxSubArray(int[] nums) {
        int n = nums.length;
        int max=Integer.MIN_VALUE;
        int sum = 0;

        for(int i=0;i<n;i++){
            sum = sum+nums[i];

            if(sum>max){
                max=sum;
            }
            if(sum<0){
                sum =0;
            }
        }
        return max;
    }

    //Kadane's algorithm-->O[N)]
    public static int maxSubArray2(int[] nums) {
       int maxSoFar=nums[0];
       int currMax=nums[0];
       for(int i=1;i< nums.length;i++){
           currMax = Math.max(nums[i],nums[i]+currMax);
           maxSoFar = Math.max(currMax,maxSoFar);
       }
       return maxSoFar;
    }
}
