package arrays;

import java.util.Arrays;

public class ProductOfArray {
    public static void main(String[] args) {
        int [] nums={1,2,3,4};
        System.out.println("Product---" + Arrays.toString(productExceptSelf(nums)));

    }

    public static int[] productExceptSelf(int[] nums) {
        int [] ans = new int[nums.length];
        int res =1;
        for(int i=0;i<nums.length;i++){
            ans[i]=res;
            res = res*nums[i];

        }
        res =1;
        for(int j=nums.length-1;j>=0;j--){
            ans[j] = res*ans[j];
            res = res*nums[j];
        }
return ans;
    }
}
