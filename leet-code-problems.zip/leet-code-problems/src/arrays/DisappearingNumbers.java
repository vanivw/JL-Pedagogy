package arrays;

import java.util.ArrayList;
import java.util.List;

public class DisappearingNumbers {

    public static List<Integer> findDisappearedNumbers(int[] nums) {
        List<Integer> result = new ArrayList<>();

        for(int i=0;i< nums.length;i++){
            int idx = Math.abs(nums[i]) - 1;
            if(nums[idx] < 0)
                continue;
            nums[idx] *= -1;
        }

        for(int i=0;i<nums.length;i++){
            if(nums[i] > 0){
                result.add(i+1);
            }
        }
        return result;
    }

    public static void main(String[] args) {
        int [] nums = new int[]{4, 3, 2, 7, 8, 2, 3, 1};
        System.out.println("Disappearing numbers---"+ findDisappearedNumbers(nums));
    }
    /*
    Time and Space Complexity
The time complexity of the provided code is O(n). This is because the code consists of a single loop that goes through
the nums array with n elements exactly once, marking each number that has been seen by negating the value
at the index corresponding to that number.
 The loop to create the output list also runs for n elements, so the entire operation is linear.

The space complexity of the code is O(1), as it only uses constant extra space.
The input list is modified in place to keep track of which numbers have been seen.
The list of disappeared numbers is the only additional space used, and it's the output of the function,
 which typically isn't counted towards space complexity.
     */
}
