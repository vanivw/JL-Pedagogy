package arrays;

import java.util.ArrayList;
import java.util.List;

public class DuplicateArrayWithConstantSpace {
    public static void main(String[] args) {
        int [] nums = {4,3,2,7,8,2,3,1};
        System.out.println("duplicates in array: "+findDuplicates(nums) );

    }
    public static List<Integer> findDuplicates(int[] nums) {
        List<Integer> resultset = new ArrayList<>();
        for(int i=0;i<nums.length;i++){
            //Get the index, the element corresponds to
            int index = Math.abs(nums[i]) - 1;
            // if the number is already negative, it means we are encountering it twice
            if(nums[index] < 0){
                resultset.add(index + 1);
            }
            //Flip the number at the index to negative
            nums[index] = nums[index] * -1;
        }
        return resultset;
    }
}
