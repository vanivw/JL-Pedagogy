package arrays;

import java.util.ArrayList;
import java.util.List;

public class SequentialDigits {

    public static void main(String[] args) {
        System.out.println("Seuential f=diguts are:---" +sequentialDigits(100,300));

    }

    public static List<Integer> sequentialDigits(int low, int high) {
        String s ="123456789";
        List<Integer> ans = new ArrayList<>();
        for(int i=0;i<s.length();i++){
            for(int j=i+1;j<s.length();j++){
                String temp = s.substring(i,j);
                int num = Integer.parseInt(temp);
                if(num>=low && num <= high){
                    ans.add(num);
                }
            }
        }
return ans;
    }
}
