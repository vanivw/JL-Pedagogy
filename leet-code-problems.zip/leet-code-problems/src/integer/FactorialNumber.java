package integer;

public class FactorialNumber {
    public static void main(String[] args) {
        System.out.println("Factorial of number:-" +factRec(4));

    }

    public static int fact(int n){
        int fact=1;
        for(int i=1;i<=n;i++){
            fact = fact*i;
        }
        return fact;
    }

    //using recursion
    public static int factRec(int n){
        if(n==0){
            return 1;
        }

        return n* fact(n-1);
    }
}
