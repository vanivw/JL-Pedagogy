package integer;

/*
Given an integer x, return true if x is a
palindrome
, and false otherwise.
 */
public class PalindromeNumber {
    public static void main(String[] args) {
System.out.println("Palindrome:" +isPalindrome(121));
    }
    public static boolean isPalindrome(int x) {
        int num =x;
        int rev=0;
        while(num >0){
            rev = (rev*10) +(num%10);
            num = num/10;
        }
        if(rev ==x){
            return true;
        }

 return false;
    }
}
