package integer;

public class Power {
    public static void main(String[] args) {

        System.out.println("Power using long:--"+power(2,3));
        System.out.println("Power using double:--"+myPow(2.0,10));
        System.out.println("Power using buildtin:--"+myPowUsingInbuiltIn(2.0,10));
        System.out.println("Power using recursion:--"+myPowUsingRecursion(2.0,10));
    }

    public static long power(int x, int n)
    {
        // Initialize result by 1
        long pow = 1L;

        // Multiply x for n times
        for (int i = 0; i < n; i++) {
            pow = pow * x;
        }

        return pow;
    }

    public static double myPow(double x, int n) {
        double pow = 1.0;

        // Multiply x for n times
        for (int i = 0; i < n; i++) {
            pow = pow * x;
        }

        return pow;
    }

    public static double myPowUsingInbuiltIn(double x, int n) {

        return Math.pow(x,n);
    }

    public static double myPowUsingRecursion(double x, int n) {
    if(n==0){
        return 1.0;
    }
    if(x==0.0){
        return 0.0;
    }

        return x*myPowUsingRecursion(x,n-1);
    }
}
