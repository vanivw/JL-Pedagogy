package hashtable;

public class Hashtable {

    private HashNode[] buckets;
    private int numOfBuckets;
    private int size;

    public Hashtable(){
        this(10);
    }

    public Hashtable(int capacity){
        this.numOfBuckets = capacity;
        this.buckets = new HashNode[numOfBuckets];
        this.size=0;
    }

    private class HashNode{
        private Integer key;
        private String value;
        private HashNode next;

        public HashNode(Integer key, String value){
            this.key =key;
            this.value = value;
        }
    }

    public int size(){
        return size;
    }

    public boolean isEmpty(){
        return size==0;
    }

    public void put(Integer key,String value){
        if(key==null || value==null){
            throw new IllegalArgumentException("Key or Value is null");

        }
        int bucketIndex= getBucketIndex(key);
       HashNode head= buckets[bucketIndex];
       while(head!=null){
           if(head.key.equals(key)){
               head.value=value;
           }
           head = head.next;
       }
size++;
         head= buckets[bucketIndex];
         HashNode node = new HashNode(key,value);
         node.next=head;
         buckets[bucketIndex]= node;



    }

    private int getBucketIndex(Integer key) {
        return key% numOfBuckets;
    }

    public String get(Integer key){
        if(key==null ){
            throw new IllegalArgumentException("Key or Value is null");

        }
        int bucketIndex= getBucketIndex(key);
        HashNode head= buckets[bucketIndex];
        while(head!=null){
            if(head.key.equals(key)){
                return head.value;
            }
            head = head.next;
        }
        return null;
    }

    public String remove(Integer key){
        if(key==null ){
            throw new IllegalArgumentException("Key or Value is null");
        }
        int bucketIndex= getBucketIndex(key);
        HashNode head= buckets[bucketIndex];
        HashNode previous=null;
        while(head!=null){
            if(head.key.equals(key)){
                break;
            }
            previous = head;
            head = head.next;
        }

        if(head==null){
            return null;
        }
        size--;
        if(previous !=null){
            previous.next = head.next;

        }else{
            buckets[bucketIndex]=head.next;
        }

        return head.value;
    }

    public static void main(String[] args) {
        Hashtable h= new Hashtable(10);
        h.put(105,"John");
        h.put(21,"Marie");
        h.put(21,"Willa");
        h.put(42,"Preeti");
        System.out.println("Elements in hashtable:" +h.size());
        System.out.println("Get the value:" +h.get(42));
        System.out.println("Remove the key:" +h.remove(21));
        System.out.println("Elements in hashtable after removing:" +h.size());
    }
}
