package dynamicprogramming;

public class LongestIncreasingSubsequence {
    public static void main(String[] args) {
        int [] nums={0,1,0,3,2,3};
        System.out.println("Length---" +lengthOfLIS(nums));

    }
    public static int lengthOfLIS(int[] nums) {
        int [] T = new int[nums.length];

        //starts main pointetr
        for(int i=1;i<nums.length;i++){
            //starts second pointer
            for(int j=0;j<i;j++){
                if(nums[i] > nums[j]){
                   if(T[j]+1 >T[i]){
                       T[i] = T[j]+1;
                   }
                }
            }
        }

        //find the max value
        int maxIndex=0;
        for(int i=0;i<T.length;i++){
            if(T[i]>T[maxIndex]){
                maxIndex=i;
            }

        }
        return T[maxIndex]+1;
    }
}
