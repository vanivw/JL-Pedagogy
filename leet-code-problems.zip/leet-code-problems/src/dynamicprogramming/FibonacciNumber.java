package dynamicprogramming;

/*
Fibonacci number is series os numbers in which first two numbers are 0 and 1.
After that each number is the sum of the two preceding numbers.
 */
public class FibonacciNumber {

    public static void main(String[] args) {
        System.out.println("Fib:---" +fibArrays(3));


        for(int i = 0; i < 3; i++){
            System.out.print(fibRec(i) +" ");
        }

    }
    // using while loop
    public static int fib(int n) {
        int f1=0,f2=1;
        while(n>1){
           int f3=f1+f2;
            f1=f2;
            f2=f3;
          n--;
        }
return f2;
    }

    //using for loop
    public static int fibFor(int n) {
        int f1=0,f2=1, f3=0;
       for(int i=2;i<=n;i++){
           f3=f1+f2;
           f1=f2;
           f2=f3;

       }
        return f3;
    }

    //using Recursive
    public static int fibRec(int n) {
       if(n==0){
           return 0;
       }else if(n==1){
           return 1;
       }else{
           return fibRec(n-1)+fib(n-2);
       }
    }

    //using dynamic programming bottom up approach--> which started from 0th index and 1st index

    public static int fibArrays(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        int [] dp = new int [n + 1];
        dp[0] = 0;
        dp[1] = 1;
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        return dp[n];
    }
    /*
    Examples of dynamic programming:
    1. House Robber
2. Best Time to Buy and Sell Stock
3. Climbing Stairs
     */
}
