package linkedlist;

import java.util.NoSuchElementException;

public class CircularLinkedLstImpl {

    private ListNode last;
    private int length;

    public CircularLinkedLstImpl(){
        last=null;
        length=0;
    }

    public int length(){
        return length;
    }

    public boolean isEmpty(){
        return length==0;
    }

    public void display(){
        if(last==null){
            return;
        }
        ListNode first = last.next;
        while(first!=last){
            System.out.print(first.data +" ");
            first = first.next;
        }
        System.out.print(first.data +" ");
        System.out.println(" ");
    }

    public void insertFirst(int data){
        ListNode temp = new ListNode(data);
        if(last==null){
            last=temp;
        }else{
            temp.next=last.next;
        }
        last.next = temp;
        length++;
    }

    public void insertLast(int data){
        ListNode temp = new ListNode(data);
        if(last == null){
            last = temp;
            last.next=last;
        }else{
            temp.next = last.next;
            last.next = temp;
            last = temp;
        }
        length++;
    }

    public ListNode deleteFirst(){
        if(isEmpty()){
            throw new NoSuchElementException("List is empty");
        }
        ListNode temp = last.next;
        if(last.next == last){
            last =null;
        }else{
            last.next=temp.next;
        }
        temp.next=null;
        length--;
        return temp;

    }

    /*
    delet the first node and return the data
     */
    public int delete(){
        if(isEmpty()){
            throw new NoSuchElementException("List is empty");
        }
        ListNode temp = last.next;
        int result = temp.data;
        if(last.next == last){
            last =null;
        }else{
            last.next=temp.next;
        }
        //temp.next=null;
        length--;
        return result;

    }

    public static void main(String[] args) {
        CircularLinkedLstImpl cll = new CircularLinkedLstImpl();
        System.out.println("Insert at the beginning of the list");
        cll.insertFirst(10);
        cll.insertFirst(20);
        cll.insertFirst(30);
        cll.display();
        System.out.println("Deleted at the beginning of the list");
        cll.deleteFirst();
        cll.display();

        System.out.println("Insert at the end of the list");
        CircularLinkedLstImpl cll2 = new CircularLinkedLstImpl();
        cll2.insertLast(5);
        cll2.insertLast(10);
        cll2.insertLast(15);
        cll2.display();
        System.out.println("Deleted at the beginning of the list");
        cll2.deleteFirst();
        cll2.display();
    }
    private class ListNode{
        private int data;
        private ListNode next;
        public ListNode(int data){
            this.data = data;
        }
    }
}
