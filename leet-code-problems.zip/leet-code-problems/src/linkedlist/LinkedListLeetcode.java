package linkedlist;

public class LinkedListLeetcode {
    Node start;

    public void deleteNode(Node node) {
        node.setData(node.getNext().getData());
        node.setNext(node.getNext().getNext());
    }

    public Node insertBegining(Node head, int data){
        Node newNode = new Node();
        newNode.setData(data);
        newNode.setNext(head);
        head = newNode;
        return head;
    }


    public Node insertEnd(Node head, int data){
        Node newNode = new Node();
        newNode.setData(data);
        newNode.setNext(null);
        Node p = head;
        while(p.getNext()!=null){
            p=p.getNext();
        }
        p.setNext(newNode);
        return head;
    }


    public Node insertMiddle(Node head, int data, int pos){
        Node newNode = new Node();
        newNode.setData(data);
        Node p = head;
        for(int i=0;i<pos;i++){
            p=p.getNext();
        }
        newNode.setNext(p.getNext());
        p.setNext(newNode);
        return head;
    }


    public Node deleteBegining(Node head){
         head = head.getNext();

        return head;
    }

    public Node deleteEnd(Node head){
        Node p= head;
        while(p.getNext().getNext()!=null){
            p=p.getNext();
        }
        p.setNext(null);

        return head;
    }

    public Node deletePos(Node head, int data, int pos){

        Node p = head;
        for(int i=0;i<pos-1;i++){
            p = p.getNext();
        }
        Node delNode = p.getNext();
        Node nxtNode = delNode.getNext();
        p.setNext(nxtNode);

        return head;
    }



    public void display(Node head){

        while(head!=null){
            System.out.print(head.getData() + " --->");
            head=head.getNext();
        }
        System.out.print("null");
        System.out.println(" ");
    }

    public int get(Node n,int index) {
        Node p= n;
        int count=0;

        while(count<index-1){
            p =p.getNext();
            count++;
        }
        return p.getData();

    }


    public Node reverseList(Node head) {
        if (head == null) {
            return head;
        }
       Node current =head;
        Node previous = null;
        Node next=null;
        while(current!=null){
            next=current.getNext();
            current.setNext(previous);
            previous = current;
            current=next;

        }
return previous;
    }

    public Node middleNode(Node head) {
        if(head == null){
            return head;
        }
        Node slowptr = head;
        Node fastptr= head;
        while(fastptr!=null && fastptr.getNext()!= null){
            slowptr=slowptr.getNext();
            fastptr =fastptr.getNext().getNext();
        }
        return slowptr;
    }

    public Node deleteDuplicates(Node head) {
        if(head==null){
            return head;
        }
        Node current=head;
        while(current!=null && current.getNext()!=null){
            if(current.getData() == current.getNext().getData()) {
                current.setNext(current.getNext().getNext());
            }else{
                current= current.getNext();
            }
        }

return head;
    }

    public static void main(String[] args) {
        /*Deleting node from leetcode
         */
        LinkedListLeetcode ll=new LinkedListLeetcode();

        Node head = new Node();
        head.setData(10);
        Node second = new Node();
        second.setData(10);
        Node third = new Node();
        third.setData(30);
        Node fourth = new Node();
        fourth.setData(40);
        Node fifth = new Node();
        fifth.setData(40);
        fifth.setNext(null);
        fourth.setNext(fifth);
        third.setNext(fourth);
        second.setNext(third);
        head.setNext(second);


        System.out.println("Before reversing/deleting");
        ll.display(head);
      Node del=  ll.deleteDuplicates(head);
      ll.display(del);
        System.out.println("Middlenode");
        Node m= ll.middleNode(head);
        ll.display(m);
       Node p= ll.reverseList(head);
        System.out.println("After reversing/deleting");
        ll.display(p);
       // System.out.println("Getting the element"+ ll.get(head,4));
        System.out.println("After deleting");
        ll.deleteNode(second);
        ll.display(head);


    }
}
