package linkedlist;

/*
You are given two non-empty linked lists representing two non-negative integers. The digits are stored in reverse order, and each of their nodes contains a single digit. Add the two numbers and return the sum as a linked list.

You may assume the two numbers do not contain any leading zero, except the number 0 itself.



Example 1:
Input: l1 = [2,4,3], l2 = [5,6,4]
Output: [7,0,8]
Explanation: 342 + 465 = 807.
 */
public class TwoNumbers {
    public static void main(String[] args) {
        Node a = createNode1();

        Node b= createNode2();
        System.out.println("Before addition");
        display(a);
        display(b);
        Node sum = addTwoNumbers(a,b);
        System.out.println("After addition");
        display(sum);




    }

    public static void display(Node p){
        // Node p = start;
        while(p!=null){
            System.out.print(p.getData() + " --->");
            p=p.getNext();
        }
        System.out.print("null");
        System.out.println(" ");
    }


    public static Node createNode1(){
        Node head = new Node();
        head.setData(2);
        Node second = new Node();
        second.setData(4);
        Node third = new Node();
        third.setData(3);
       /* Node fourth = new Node();
        fourth.setData(4);
        Node fifth = new Node();
        fifth.setData(5);
        Node sixth = new Node();
        sixth.setData(6);*/
        head.setNext(second);
        second.setNext(third);
        third.setNext(null);
        //fourth.setNext(fifth);
       // fifth.setNext(sixth);
       // sixth.setNext(third);
        return head;
    }

    public static Node createNode2(){
        Node head = new Node();
        head.setData(5);
        Node second = new Node();
        second.setData(6);
        Node third = new Node();
        third.setData(4);
      /*  Node third = new Node();
        third.setData(3);
        Node fourth = new Node();
        fourth.setData(4);
        Node fifth = new Node();
        fifth.setData(5);
        Node sixth = new Node();
        sixth.setData(6);*/
        head.setNext(second);
        second.setNext(third);
        third.setNext(null);
        /*third.setNext(fourth);
        fourth.setNext(fifth);
        fifth.setNext(sixth);
        sixth.setNext(third);*/
        return head;
    }
    public static Node addTwoNumbers(Node l1, Node l2) {
   Node dummy = new Node();
   dummy.setData(0);
   dummy.setNext(null);
   Node tail=dummy;
        int carry=0;
   while(l1!=null || l2!=null){
       int x = (l1!=null)?l1.getData():0;
       int y = (l2!=null)?l2.getData():0;
       int sum = carry+x+y;
       carry=sum/10;
       int mod=sum%10;
       Node n = new Node();
       n.setData(mod);
       n.setNext(null);
       tail.setNext(n);
       tail= tail.getNext();
       if(l1!=null){
           l1=l1.getNext();
       }
       if(l2!=null){
           l2=l2.getNext();
       }
       if(carry>0){
           Node n1 = new Node();
           n1.setData(carry);
           n1.setNext(null);
           tail.setNext(n1);
       }
   }
   return dummy.getNext();
    }
}
