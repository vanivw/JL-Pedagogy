package linkedlist;

public class LinkedListImpl {

    Node start;

    public void insert(int data){
        if(start==null){
            Node n = new Node();
            n.setData(data);
            n.setNext(null);
            start =n;
        }else{
            Node p=start;
            Node n1 = new Node();
            n1.setData(data);
            n1.setNext(null);
            p.setNext(n1);
        }

    }

    public void insertFirst(int data){
        Node p= start;
        Node n= new Node();
        n.setData(data);
        n.setNext(p);
        start = n;
    }

    public void insertPos(int data, int pos){
        if(pos==1){
            Node n = new Node();
            n.setData(data);
            n.setNext(start);
            start=n;
        }else{
            Node previous = start;
            int count=1;
            while(count<pos-1){
                previous = previous.getNext();
                count++;
            }
            Node n = new Node();
            n.setData(data);
            Node current = previous.getNext();
            previous.setNext(n);
            n.setNext(current);


        }

    }

    public void insertLast(int data){
        if(start==null){
            Node n = new Node();
            n.setData(data);
            n.setNext(null);
            start=n;
        }
        else{
            Node current = start;
            while(current.getNext()!=null){
                current = current.getNext();
            }
            Node n1 = new Node();
            n1.setData(data);
            n1.setNext(null);
            current.setNext(n1);
        }
    }

    public Node deleteFirst(){
        if(start==null){
            return null;
        }
        Node temp = start;
        start = start.getNext();
        temp.setNext(null);
        return temp;

    }

    public Node deleteLast(){
        if(start == null || start.getNext() == null){
            return null;
        }
        Node current = start;
        Node previous = null;
        while(current.getNext()!=null){
            previous = current;
            current = current.getNext();
        }
        previous.setNext(null);
        return current;
    }

    public void delete(int data){
        Node p = start;
      Node p1=null;
      Node p2=null;
      while(p!=null && p.getNext()!=null){
          if(p.getNext().getData() == data){
              p1=p.getNext();
              p2=p1.getNext();
              p.setNext(p2);
          }else{
              p=p.getNext();
          }
      }
    }
    public void deleteKey(int data){
        Node current = start;
        Node temp=null;
        if(current!=null &&current.getData() ==data ){
            start = current.getNext();
            return;

        }
        while(current!=null && current.getData()!=data){
            temp=current;
            current = current.getNext();
        }
        if(current == null){
            return;
        }

        temp.setNext(current.getNext());

    }


    public void deleteNode(Node n){
        n.setData(n.getNext().getData());
        n.setNext(n.getNext().getNext());
    }

    public Node getNode(Node head,int val){
        if(head==null){
            return null;
        }
        while(head.getData()!=val){
            head = head.getNext();
        }
        return head;
    }

    public void deletePos(int pos){
        if(pos==1){
            start = start.getNext();
        }
        else{
            Node previous = start;
            int count=1;
            while(count<pos-1){
                previous = previous.getNext();
                count++;
            }
            Node current = previous.getNext();
            previous.setNext(current.getNext());
        }
    }

    public boolean find(int data){
        Node p = start;
        while(p!=null) {
            if (p.getData() == data) {
                return true;
            }
            p=p.getNext();
        }
        return false;
    }

    //time complexity--O(n) and space complexity: O(1)
    public Node reverse(){
        if (start == null) {
            return null;
        }
        Node current =start;
        Node previous=null;
        Node next=null;
        while(current!=null){
            next= current.getNext();
            current.setNext(previous);
            previous=current;
            current = next;

        }
        return previous;
    }

    public Node getNthNode(int n){
        if(start==null){
 return start;
        }
        if(n<=0){
            throw new IllegalArgumentException("Invalid n value-" +n);
        }
        Node mainptr=start;
        Node refptr= start;
        int count=0;
        while(count<n){
            if(refptr==null){
                throw new IllegalArgumentException(n +" is greater number of nodes in the list");
            }
            refptr=refptr.getNext();
            count++;

        }

        while(refptr!=null){
            mainptr=mainptr.getNext();
            refptr =refptr.getNext();
        }
return mainptr;
    }

public int length(){
        int count=0;
        Node current = start;
        while(current!=null){
            count++;
            current = current.getNext();
        }
        return count;
}
    public Node deleteDuplicates(Node head) {
        if(head==null){
            return head;
        }
        Node current=head;
        while(current!=null && current.getNext()!=null){
            if(current.getData() == current.getNext().getData()) {
                current.setNext(current.getNext().getNext());
            }else{
                current= current.getNext();
            }
        }

        return head;
    }

    public void display(){
        Node p = start;
        while(p!=null){
            System.out.print(p.getData() + " --->");
            p=p.getNext();
        }
        System.out.print("null");
        System.out.println(" ");
    }

    public void display(Node p){
       // Node p = start;
        while(p!=null){
            System.out.print(p.getData() + " --->");
            p=p.getNext();
        }
        System.out.print("null");
        System.out.println(" ");
    }

    public Node insertSortedList(int data){
        Node newNode = new Node();
        newNode.setData(data);
        Node current=start;
        Node temp=null;
        while(current!=null && current.getData()< newNode.getData()){
            temp=current;
            current = current.getNext();
        }
        newNode.setNext(current);
        temp.setNext(newNode);
        return start;
    }

    public boolean containsLoop(Node head){
        Node fastptr=head;
        Node slwptr=head;
        while(fastptr!=null && fastptr.getNext()!=null){
            fastptr = fastptr.getNext().getNext();
            slwptr =slwptr.getNext();
            if(slwptr==fastptr){
                return true;
            }
        }
        return false;
    }

    public Node getStartingLoop(Node head){
        Node fastptr=head;
        Node slwptr=head;
        while(fastptr!=null && fastptr.getNext()!=null){
            fastptr = fastptr.getNext().getNext();
            slwptr =slwptr.getNext();
            if(slwptr==fastptr){
                return getStartingNodeOfLoop(slwptr,head);
            }
        }
        return null;
    }

    private Node getStartingNodeOfLoop(Node slwptr,Node head){
        Node temp = head;
        while(temp!=slwptr){
            temp = temp.getNext();
            slwptr=slwptr.getNext();
        }
        return temp;//starting node of the loop
    }

    public Node removingLoop(Node head){
        Node fastptr=head;
        Node slwptr=head;
        while(fastptr!=null && fastptr.getNext()!=null){
            fastptr = fastptr.getNext().getNext();
            slwptr =slwptr.getNext();
            if(slwptr==fastptr){
                 removeLoop(slwptr,head);
            }
        }
        return null;
    }

    private void removeLoop(Node slwptr,Node head){
        Node temp=head;
        while(temp.getNext()!=slwptr.getNext()){
            slwptr=slwptr.getNext();
            temp=temp.getNext();
        }
        slwptr.setNext(null);
    }

    public Node merge(Node a,Node b){
        Node dummy = new Node();
        dummy.setData(0);
        dummy.setNext(null);
        Node tail = dummy;
        while(a!=null && b!=null){
            if(a.getData() <= b.getData()){
                tail.setNext(a);
                a=a.getNext();
            }else{
                tail.setNext(b);
                b=b.getNext();
            }
            tail=tail.getNext();
        }
        if(a==null){
            tail.setNext(b);
        }else{
            tail.setNext(a);
        }
        return dummy.getNext();
    }

    public Node createLoop(){
        Node head = new Node();
        head.setData(1);
        Node second = new Node();
        second.setData(2);
        Node third = new Node();
        third.setData(3);
        Node fourth = new Node();
        fourth.setData(4);
        Node fifth = new Node();
        fifth.setData(5);
        Node sixth = new Node();
        sixth.setData(6);
        head.setNext(second);
        second.setNext(third);
        third.setNext(fourth);
        fourth.setNext(fifth);
        fifth.setNext(sixth);
        sixth.setNext(third);
return head;
    }



    public static void main(String[] args) {

        LinkedListImpl ll = new LinkedListImpl();
        ll.insertFirst(10);
        ll.insertFirst(20);
        ll.insertFirst(30);
        ll.insertFirst(40);
        ll.insertFirst(50);
        ll.display();
        System.out.println("Nth node of the list is---"+ll.getNthNode(2).getData());

        System.out.println("Deleting elements at the given node");
        ll.delete(30);
       // System.out.println(ll.delete(20));
        ll.display();
        System.out.println("Inserting elements at the last");
        LinkedListImpl ll2 = new LinkedListImpl();
        ll2.insertLast(80);
        ll2.insertLast(90);
        ll2.insertLast(100);
        ll2.insertLast(120);
        ll2.insertLast(140);
        ll2.display();
        System.out.println("Deleting elements at the first");
       // System.out.println(ll2.deleteFirst().getData());
        ll2.display();
        LinkedListImpl ll3 = new LinkedListImpl();
        ll3.insertPos(3,1);//3-->null
        ll3.insertPos(5,2);//3-->5--null
        ll3.insertPos(4,1);//4-->3-->5--null
        ll3.insertPos(6,2);//4-->6-->3-->5--null
        ll3.insertPos(7,5);//4-->6-->3-->5--7-->null
        ll3.display();
        System.out.println("Deleting elements at the pos");
        ll3.deletePos(3);
        ll3.display();
      // Node n= ll3.reverse();
       // ll3.display(n);

        LinkedListImpl ll4 = new LinkedListImpl();
        ll4.insertLast(1);
        ll4.insertLast(1);
        ll4.insertLast(2);
        ll4.insertLast(3);
        ll4.insertLast(3);
        System.out.println("Before sorting");
        ll4.display();
        System.out.println("After sorting");
       Node s= ll4.deleteDuplicates(ll4.start);
       ll4.display(s);

        LinkedListImpl ll5 = new LinkedListImpl();
        ll5.insertLast(1);
        ll5.insertLast(8);
        ll5.insertLast(10);
        ll5.insertLast(16);
        System.out.println("Before inserting");
        ll5.display();
       Node sortedNode= ll5.insertSortedList(11);
        System.out.println("After inserting");
        ll5.display(sortedNode);

        LinkedListImpl ll6 = new LinkedListImpl();
       Node head= ll6.createLoop();
      System.out.println("Containeloop" + ll6.containsLoop(head));
        Node loopdata=ll6.getStartingLoop(head);
      // Node loopData= ll6.getStartingNodeOfLoop(slowptr,head);
       System.out.println("Start node in loop"+loopdata.getData());
        System.out.println("Remove loop");
        ll6.removingLoop(head);
        ll6.display(head);

        LinkedListImpl ll7 = new LinkedListImpl();
        ll7.insertLast(1);
        ll7.insertLast(4);
        ll7.insertLast(8);

        LinkedListImpl ll8 = new LinkedListImpl();
        ll8.insertLast(3);
        ll8.insertLast(5);
        ll8.insertLast(8);
        ll8.insertLast(9);
        ll8.insertLast(14);
        ll8.insertLast(18);
        System.out.println("Before Merging ");
        ll7.display();
        ll8.display();

        LinkedListImpl mergeList = new LinkedListImpl();
        System.out.println("Node a "+ll7.start);
        System.out.println("Node b "+ll8.start);
        Node sorted=mergeList.merge(ll7.start,ll8.start);
        System.out.println("After Merging ");
        mergeList.display(sorted);



    }

}
