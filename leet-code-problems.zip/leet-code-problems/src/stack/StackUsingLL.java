package stack;

import java.util.EmptyStackException;
import java.util.NoSuchElementException;

public class StackUsingLL {
    private ListNode top;
    private int length;

    class ListNode{
        private ListNode next;
        private int data;
        ListNode(int data){
            this.data=data;
        }
    }

    public StackUsingLL(){
        top=null;
        length=0;
    }

    public int length(){
        return length;
    }

    public boolean isEmpty(){
        return length==0;
    }


public void push(int data){
        ListNode temp= new ListNode(data);
        temp.next=top;
        top=temp;
        length++;
}

public int pop(){
        if(isEmpty()){
            throw new EmptyStackException();
        }
        int result=top.data;
        top=top.next;
        length--;
        return result;
}

public int peek(){
        if(isEmpty()){
            throw new EmptyStackException();
        }
        return top.data;
}

    public static void main(String[] args) {
        StackUsingLL sll = new StackUsingLL();
        sll.push(10);
        sll.push(20);
        sll.push(30);
        System.out.println("Peek value--" +sll.peek());
        sll.pop();
        System.out.println("Peek value after pop--" +sll.peek());
    }
}
