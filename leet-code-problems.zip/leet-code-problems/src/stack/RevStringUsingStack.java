package stack;

import java.util.Stack;

public class RevStringUsingStack {
    public static void main(String[] args) {
        String str="ABCD";
        System.out.println("Before reversing " +str);
        System.out.println("After reversing " +revString(str));

    }
    public static String revString(String input){
        char[] ch=input.toCharArray();
        Stack<Character> stack = new Stack<>();
        for(char c:ch){
            stack.push(c);
        }
        for(int i=0;i<input.length();i++){
           ch[i]= stack.pop();
        }
        return new String(ch);
    }
}
