package stack;

import java.util.Stack;

public class ValidParanthesis {
    public static void main(String[] args) {
        System.out.println("Valid:"+isValid("()"));

    }
    public static boolean isValid(String s) {
      char[]ch=  s.toCharArray();
    Stack<Character> st = new Stack<>();
      for(Character c: ch){
          if(c == '(' || c=='{' || c=='['){
              st.push(c);
          }else{
              if(st.isEmpty()){
                  return false;
              }else {
                  Character top = st.peek();
                  if(c == ')' && top =='(' ||c == '}' && top =='{'  || c == ']' && top =='[' ){
                      st.pop();
                  }
              }
          }
      }


 return st.isEmpty();
    }
}
