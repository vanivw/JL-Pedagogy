package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MultipleOfFive {
    public static void main(String[] args) {
            List<Integer> list = Arrays.asList(5,10,32,87,45,98,30);
            list.stream().filter(i->i%5 ==0).forEach(System.out::println);
            int max = list.stream().max(Comparator.naturalOrder()).get();
            System.out.println("Max element--" +max);
            int min = list.stream().min(Comparator.naturalOrder()).get();
        System.out.println("Min element--" +min);

        List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);
        System.out.println("Min 3 elements--" );
        listOfIntegers.stream().sorted().limit(3).forEach(System.out::println);
        System.out.println("Max 3 elements--" );
        listOfIntegers.stream().sorted(Comparator.reverseOrder()).limit(3).forEach(System.out::println);

            int [] a={2,4,6,8,8,6};
            int []b ={1,3,5,7,3,1};
       int [] res= IntStream.concat(Arrays.stream(a),Arrays.stream(b)).sorted().distinct().toArray();
       System.out.println("Merged array---" + Arrays.toString(res));

       //anagrams
        String s1 = "RaceCar";
        String s2 = "CarRace";
        s1= Stream.of(s1.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
        s2= Stream.of(s2.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
        if(s1.equals(s2)){
            System.out.println("Strings are anagram");
        }else{
            System.out.println("Strings are not anagram");
        }
    }
}
