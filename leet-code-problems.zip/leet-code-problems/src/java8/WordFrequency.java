package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class WordFrequency {
    public static void main(String[] args) {

        wordFrequency();
    }
    private static void wordFrequency() {

        List<String> names = Arrays.asList("rohit", "urmila", "rohit", "urmila", "ram", "sham", "sita", "gita");
       Map<String,Long> map= names.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
System.out.println("Words frequency---" + map);

    }
}
