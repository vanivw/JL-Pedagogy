package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RemoveDuplicates {
    public static void main(String[] args) {
        List<String> listOfStrings = Arrays.asList("Java", "Python", "C#", "Java", "Kotlin", "Python");
        System.out.println("Duplicates removed:----"+removeDuplicates(listOfStrings));
        List<Integer> oneToTen = Arrays.asList(1, 2,3, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println("Duplicates removed without order:----"+removeDuplicatesWithoutOrder(oneToTen));
    }

    public static List<String> removeDuplicates(List<String > strList){
        //sort the list in reverse order
        strList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
      return  strList.stream().distinct().collect(Collectors.toList());

    }

    public static Set<Integer> removeDuplicatesWithoutOrder(List<Integer > strList){
        return  strList.stream().collect(Collectors.toSet());

    }
}
