package java8;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.partitioningBy;

public class OddOrEven {
    public static void main(String[] args) {
        List<Integer> integerList = Arrays.asList(71, 18, 42, 21, 67, 32, 95, 14, 56, 87);
     oddOrEven(integerList);

        printEvenNumberByJava8();
        printOddNumberByJava8();
        separationOfEvenOddNumberInList(integerList);

    }

    private static void printEvenNumberByJava8() {
        System.out.println("Even numbers from 0 to 10:  ");
        IntStream.rangeClosed(0,10).filter(x->x%2==0).forEach(System.out::println);
    }

    private static void printOddNumberByJava8() {
        System.out.println("Odd numbers from 0 to 10:  ");
        IntStream.rangeClosed(0,10).filter(x->x%2!=0).forEach(System.out::println);
    }

    public static void oddOrEven(List<Integer> integers){

       Map<Boolean,List<Integer>> map=integers.stream().collect(partitioningBy(i->i%2==0));

      Set<Map.Entry<Boolean, List<Integer>>> entryset =map.entrySet();
        System.out.println("********** "+ map);
      for(Map.Entry<Boolean, List<Integer>> entry: entryset){
          if(entry.getKey()){
              System.out.println("Even Numbers");
          }else{
              System.out.println("Odd Numbers");
          }
          List<Integer> integerList = entry.getValue();
          for(Integer i:integerList){
              System.out.println(i);
          }
      }
    }

    public static void separationOfEvenOddNumberInList(List<Integer> integers){
               Collection<List<Integer>> evenOddList = integers.stream()
                       .collect(collectingAndThen(partitioningBy(i -> i % 2 == 0),
                               Map::values));
               System.out.println("Separting even and odd numbers in list--" + evenOddList);

    }
}
