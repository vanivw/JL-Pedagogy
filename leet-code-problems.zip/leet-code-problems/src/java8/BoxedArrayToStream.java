package java8;

public class BoxedArrayToStream {
    public static void main(String[] args) {

    }
}
