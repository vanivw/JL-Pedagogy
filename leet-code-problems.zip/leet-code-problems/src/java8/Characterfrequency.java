package java8;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Characterfrequency {
    public static void main(String[] args) {
        String str="Today is Wednesday";
        System.out.println("Fequency of charactres-- --" +frequencyChar(str));
        System.out.println("Fequency of charactres using split-- --" +frequencyChar2(str));

    }

    public static Map<Character, Long> frequencyChar(String str){
       return str.chars().mapToObj(c ->(char)c)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

    }

    public static Map<String, Long> frequencyChar2(String str){

        return Arrays.stream(str.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
    }
}
