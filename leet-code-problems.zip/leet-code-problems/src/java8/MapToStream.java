package java8;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class MapToStream {
    public static void main(String[] args) {
        Map<Integer,String> map = new HashMap<>();
        map.put(1, "GEEKS");
        map.put(2, "DigitalOcean");
        map.put(3, "Leetcode");
        System.out.println("Before converting to stream-- " + map);
        Stream<Map.Entry<Integer,String>> res=convertMapToStream(map);
        System.out.println("After converting---" + Arrays.toString(res.toArray()));
        Stream<Integer> res1=convertKeysetToStream(map);
        System.out.println("After converting keyset to stream---" + Arrays.toString(res1.toArray()));

        Stream<String> res2=convertValuesToStream(map);
        System.out.println("After converting values to stream ---" + Arrays.toString(res2.toArray()));


    }
    public static <K, V> Stream<Map.Entry<K, V>> convertMapToStream(Map<K,V> map){
        return map.entrySet().stream();
    }

    public static <K, V> Stream<K> convertKeysetToStream(Map<K,V> map){
        return map.keySet().stream();
    }

    public static <K, V> Stream<V> convertValuesToStream(Map<K,V> map){
        return map.values().stream();
    }
}
