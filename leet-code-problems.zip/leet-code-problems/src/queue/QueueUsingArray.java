package queue;

import java.util.NoSuchElementException;

public class QueueUsingArray {
    private int []q;
    private int size;
    private int length;
    private int front;
    private int rear;

    public QueueUsingArray(int size){
        this.size=size;
        length=0;
        front=0;
        rear=0;
        q=new int[size];
    }

    public boolean isEmpty(){
        return length==0;
    }

    public boolean isFull(){
        return size==length;
    }

    public void enqueue(int data){
        if(isFull()){
            throw new IllegalArgumentException("Queue is full");
        }
        length++;
        q[rear] = data;
       // rear =(rear+1)%size;
        rear++;
    }

    public int dequeue(){
        if(isEmpty()){
            throw new NoSuchElementException("Queue is empty");
        }
        int result= q[front];
        length--;
        //front = (front+1)%size;
        front++;
        return result;
    }

    void print() {
        int i;
        if (isEmpty()) {
            System.out.println("Empty Queue");
        }
        else {
            // display the front of the queue
            System.out.println("\nFront index-> " + front);

            // display element of the queue
            System.out.println("Items -> ");
            for (i = front; i < rear; i++)
                System.out.print(q[i] + "  ");

            // display the rear of the queue
            System.out.println("\nRear index-> " + rear);
        }
    }

    public static void main(String[] args) {
        QueueUsingArray queueUsingLL = new QueueUsingArray(3);

        queueUsingLL.enqueue(10);
        queueUsingLL.enqueue(20);
        queueUsingLL.enqueue(30);
        queueUsingLL.print();

        System.out.println("Before deleting");
     queueUsingLL.dequeue();
        queueUsingLL.dequeue();
        System.out.println("after deleting");
        queueUsingLL.print();



    }
}
