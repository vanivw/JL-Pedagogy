package backtracking;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LettersOfPhoneNo {
    public static void main(String[] args) {
        System.out.println("Result--- "+ letterCombinations("23"));

    }


    public static List<String> letterCombinations(String digits) {


        if(digits.length()==0){
            return new ArrayList<>();
        }
        List<String> ans = new ArrayList<>();
        String cur="";
        backtrack(digits, ans, cur,0);
        return ans;


    }

    private static void backtrack(String digits, List<String> ans, String cur, int index) {
        Map<Character, String> digitToChar = new HashMap<>();
        digitToChar.put('2', "abc");
        digitToChar.put('3', "def");
        digitToChar.put('4', "ghi");
        digitToChar.put('5', "jkl");
        digitToChar.put('6', "mno");
        digitToChar.put('7', "pqrs");
        digitToChar.put('8', "tuv");
        digitToChar.put('9', "wxyz");
        if(digits.length() == cur.length()){
            ans.add(cur);
            return;
        }else if(index >= digits.length()){
            return;
        }else{
            String digit = digitToChar.get(digits.charAt(index));
            for(char c: digit.toCharArray()){

                backtrack(digits, ans, cur + c, index+1);
            }
        }
    }
}
