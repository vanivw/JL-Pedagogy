package backtracking;

import java.util.ArrayList;
import java.util.List;

public class Permutations {


    public static void main(String[] args) {
int [] nums = {1,2,3};
System.out.println("Permutation combinations:----- " + permute(nums));
    }

    public static List<List<Integer>> permute(int[] nums) {
        List<List<Integer>> resultList = new ArrayList<>();
        backtrackHelper(resultList, new ArrayList<>(), nums);
        return resultList;

    }

    public static void backtrackHelper(List<List<Integer>> resultList, List<Integer> tempList, int[]nums){

        //if we match the length, it is permutation
        if(tempList.size() == nums.length)
            resultList.add(new ArrayList<>(tempList));

        for(int number:nums){
            //skip if we get same element
            if(tempList.contains(number))
                continue;

            //add the new element
            tempList.add(number);

            //go back to try other element
            backtrackHelper(resultList,tempList,nums);

            //Remove the element
            tempList.remove(tempList.size()-1);
        }
    }
}
