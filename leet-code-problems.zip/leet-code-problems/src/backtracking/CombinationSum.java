package backtracking;

import java.util.ArrayList;
import java.util.List;

public class CombinationSum {
    public static void main(String[] args) {
        int [] nums={2,3,6,7};
        int target=7;
        System.out.println("Result--" + combinationSum(nums,target));

    }
    public static List<List<Integer>> combinationSum(int[] candidates, int target) {
        List<List<Integer>> comb = new ArrayList<>();
        generateCombination(0,candidates, comb, new ArrayList(),target);
        return comb;

    }

    public static void generateCombination(int start, int[] nums,List<List<Integer>> comb, List<Integer> current,int target ){

        if(target == 0){
            comb.add(new ArrayList<>(current));
        }
        if(target<0){
            return;
        }


        for(int i=start;i<nums.length;i++){
            current.add(nums[i]);
            generateCombination(i,nums,comb,current, target-nums[i]);
            current.remove(current.size()-1);
        }
    }
}
