package backtracking;

import java.util.ArrayList;
import java.util.List;

public class Combinations {

    static List<List<Integer>> ans;
    public static void main(String[] args) {
System.out.println("Result---" + combine(4,3));
    }
    public static List<List<Integer>> combine(int n, int k) {
      ans = new ArrayList<>();
      helper(1,n,k,new ArrayList<Integer>());
      return ans;

    }

    private static void helper(int start, int n, int k, ArrayList<Integer> sub) {
         if(k==0){
             ans.add(new ArrayList<>(sub));
             return;

         }
         for(int i=start;i<=n-k+1;i++){
             sub.add(i);
             helper(i+1,n,k-1,sub);
             sub.remove(sub.size()-1);


         }
    }
}
