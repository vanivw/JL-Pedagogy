package backtracking;

import java.util.ArrayList;
import java.util.List;

public class GenerateParanthesis {

    public static void main(String[] args) {
        System.out.println("Result-- " + generateParenthesis(2));

    }
    public static List<String> generateParenthesis(int n) {
        List<String> result = new ArrayList<>();
        valid(n,0,0,result,"");
        return result;

    }

    private static void valid(int n, int opnbr, int clsbr, List<String> result, String current) {

        if(n == opnbr  && n== clsbr){
            result.add(current);
            return;
        }
        if(n < opnbr || n < clsbr){
            return;
        }

        if(clsbr < opnbr){
            valid(n,opnbr+1,clsbr,result,current+"(");
            valid(n,opnbr,clsbr+1,result,current+")");
        }else{
            valid(n,opnbr+1,clsbr,result,current+"(");
        }
    }

}
