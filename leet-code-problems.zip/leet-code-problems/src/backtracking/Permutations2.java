package backtracking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Permutations2 {
    public static void main(String[] args) {
        int [] nums = {1,2,1,3};
        System.out.println("Permutation combinations:----- " + permute(nums));
    }

    public static List<List<Integer>> permute(int[] nums) {
        List<List<Integer>> resultList = new ArrayList<>();
        Arrays.sort(nums);
        backtrackHelper(resultList, new ArrayList<>(), nums, new boolean[nums.length]);
        return resultList;

    }

    public static void backtrackHelper(List<List<Integer>> resultList, List<Integer> tempList, int[]nums, boolean []used){

        //if we match the length, it is permutation
        if(tempList.size() == nums.length && !resultList.contains(tempList)) {
            resultList.add(new ArrayList<>(tempList));
            return;
        }

        for(int i=0;i<nums.length;i++){


            //skip if we get same element
            if (used[i]) continue;

            used[i] =true;
            //add the new element
            tempList.add(nums[i]);

            //go back to try other element
            backtrackHelper(resultList,tempList,nums, used);

            used[i]=false;

            //Remove the element
            tempList.remove(tempList.size()-1);
        }
    }
}
