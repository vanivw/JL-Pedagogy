package binaryTree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class InvertTree {

 TreeNode root;
    private class TreeNode{
        private int data;
        private InvertTree.TreeNode left;
        private InvertTree.TreeNode right;
        public TreeNode(int data){
            this.data = data;

        }
    }

    public  void createBinaryTree(){
        InvertTree.TreeNode first = new InvertTree.TreeNode(4);
        InvertTree.TreeNode second = new InvertTree.TreeNode(2);
        InvertTree.TreeNode third = new InvertTree.TreeNode(7);
        InvertTree.TreeNode fourth = new InvertTree.TreeNode(1);
        InvertTree.TreeNode fifth = new InvertTree.TreeNode(3);
        InvertTree.TreeNode sixth = new InvertTree.TreeNode(6);
        InvertTree.TreeNode seventh = new InvertTree.TreeNode(9);
        //TreeNode fifth = new TreeNode(5);
        root = first;// root---> first
        root.left = second;
        root.right = third; // second<--- first--->third

        second.left = fourth;
        second.right = fifth;
        third.left = sixth;
        third.right = seventh;
    }

    public static TreeNode invertTree(TreeNode root) {
        if(root==null){
            return null;
        }
        LinkedList<TreeNode> queue = new LinkedList<>();
        queue.add(root);

        while(!queue.isEmpty()){

          int size=queue.size();
          for(int i=0;i<size;i++){
              TreeNode temp=  queue.poll();
              if(temp.right!=null){
                  queue.add(temp.right);
              }
              if(temp.left!=null){
                  queue.add(temp.left);
              }
              TreeNode dummy = temp.right;
              temp.right = temp.left;
              temp.left = dummy;

          }

        }
return root;
    }

    /*
    Leet code problem for preorder traversal
     */
    public static List<Integer> preorderTraversal(TreeNode root) {
        List<Integer> list = new ArrayList<>();
        preorderTraversalHelper(list, root);
        return list;
    }

    /*
   Leet code problem for preorder traersal
    */
    private static void preorderTraversalHelper(List<Integer> list,TreeNode root) {
        if (root != null) {
            list.add(root.data);
            preorderTraversalHelper(list, root.left);
            preorderTraversalHelper(list, root.right);
        }
    }

    public static void main(String[] args) {
        InvertTree z = new InvertTree();
        z.createBinaryTree();
        System.out.println("Before Inverting tree : "+preorderTraversal(z.root));
       TreeNode res=InvertTree.invertTree(z.root);

        System.out.println("After Invert tree : "+preorderTraversal(res));

    }
}
