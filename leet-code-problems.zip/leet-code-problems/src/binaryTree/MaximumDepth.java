package binaryTree;

import java.util.LinkedList;
import java.util.Queue;

public class MaximumDepth {

    private class TreeNode{
        private int data;
        private TreeNode left;
        private TreeNode right;
        public TreeNode(int data){
            this.data = data;

        }
    }

    public TreeNode createBinaryTree2(TreeNode root){
       TreeNode first = new TreeNode(1);
        TreeNode second = new TreeNode(2);
       TreeNode third = new TreeNode(3);
        //TreeNode fourth = new TreeNode(4);
        //TreeNode fifth = new TreeNode(5);

        root = first;// root---> first
        root.right = second;
        root.right = third;// second<--- first--->third
        //third.left=fourth;
        //third.right=fifth;

        return root;
    }

    public int maxDepth(TreeNode root) {
        int height=0;
        if(root==null){
            return 0;
        }
        Queue<TreeNode> q = new LinkedList<TreeNode>();
        q.offer(root);
        while(!q.isEmpty()){
            int size = q.size();

            for(int i=0;i<size;i++){
                TreeNode temp = q.poll();
                if(temp.left!=null){
                    q.offer(temp.left);
                }
                if(temp.right!=null){
                  q.offer(temp.right);
                }
            }
            height++;
        }
        return height;
    }

    public static void main(String[] args) {
        MaximumDepth m = new MaximumDepth();
        TreeNode root =null;
        TreeNode node= m.createBinaryTree2(root);
        System.out.println("Height of the binary tree---" + m.maxDepth(node));
    }

}
