package binaryTree;

import java.util.ArrayList;
import java.util.Collections;

public class BoundaryTraversal {

  private class TreeNode{
      private int data;
      private TreeNode left;
      private TreeNode right;
      public TreeNode(int data){
          this.data = data;

      }
  }

  public TreeNode create(TreeNode root){
      TreeNode first = new TreeNode(20);
      TreeNode second = new TreeNode(8);
      TreeNode third =new TreeNode(22);
      TreeNode fourth = new TreeNode(4);
      TreeNode fifth = new TreeNode(12);
      TreeNode sixth =new TreeNode(10);
      TreeNode seventh =new TreeNode(14);
      TreeNode eighth =new TreeNode(25);


      root = first;// root---> first
      root.left = second;
      root.right =third;
     second.left = fourth;
     second.right = fifth;
     fifth.left = sixth;
     fifth.right=seventh;
     third.right=eighth;

      return root;
  }

  public boolean isLeaf(TreeNode root){
      return root.left==null && root.right==null;
  }

  public ArrayList<Integer> boundary(TreeNode root)
    {
       ArrayList<Integer> res = new ArrayList<>();
       if(root==null){
           return res;
       }
       res.add(root.data);
       if(isLeaf(root)){
           return res;
       }
       addLeftNode(root.left,res);
       addLeaves(root,res);
       addrightNode(root.right,res);
       return res;

    }

    public void addLeftNode(TreeNode root, ArrayList<Integer> res){
      TreeNode curr= root;
      while(curr!=null){
          if(!isLeaf(curr)){
              res.add(curr.data);
          }
          if(curr.left!=null){
              curr = curr.left;
          }else{
              curr=curr.right;
          }
      }
    }

    public void addrightNode(TreeNode root, ArrayList<Integer> res){
        TreeNode curr= root;
        ArrayList<Integer> temp = new ArrayList<>();
        while(curr!=null){
            if(!isLeaf(curr)){
                temp.add(curr.data);
            }
            if(curr.right!=null){
                curr = curr.right;
            }else{
                curr=curr.left;
            }
        }
        Collections.reverse(temp);
        for(int i:temp){
            res.add(i);
        }
    }

    public void addLeaves(TreeNode root, ArrayList<Integer>res){
      if(isLeaf(root)){
          res.add(root.data);
          return;
      }
      if(root.left!=null){
         addLeaves(root.left,res);
      }
        if(root.right!=null){
            addLeaves(root.right,res);
        }
    }

    public static void main(String[] args) {
        BoundaryTraversal b = new BoundaryTraversal();
        TreeNode root=null;
       TreeNode rt= b.create(root);
      ArrayList<Integer> list= b.boundary(rt);
      System.out.println("Boundaries of binary tree---"+list);
    }

}
