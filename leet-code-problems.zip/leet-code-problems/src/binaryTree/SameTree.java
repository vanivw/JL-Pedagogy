package binaryTree;

import java.util.LinkedList;
import java.util.Queue;

public class SameTree {

    TreeNode root;
    private class TreeNode{
        private int data;
        private TreeNode left;
        private TreeNode right;
        public TreeNode(int data){
            this.data = data;

        }
    }

    public  TreeNode createBinaryTree1(){
        TreeNode first = new TreeNode(1);
         TreeNode second = new TreeNode(2);
      //TreeNode third =new TreeNode(3);;

        root = first;// root---> first
        root.left = second;
        //root.right = third; // second<--- first--->third

        return root;
    }

    public  TreeNode createBinaryTree2(){
        TreeNode first = new TreeNode(1);
        TreeNode second = new TreeNode(2);
       TreeNode third = new TreeNode(3);

        root = first;// root---> first
        root.right = second;
        root.right = third; // second<--- first--->third

        return root;
    }



    public boolean isSameTree(TreeNode p, TreeNode q) {
        // Create queues for both trees.
        Queue<TreeNode> queue1 = new LinkedList<>();
        Queue<TreeNode> queue2 = new LinkedList<>();

        // Start by adding the root nodes of both trees to their respective queues.
        queue1.offer(p);
        queue2.offer(q);

        while (!queue1.isEmpty() && !queue2.isEmpty()) {
            TreeNode node1 = queue1.poll();
            TreeNode node2 = queue2.poll();

            // If the values of the current nodes are not equal, the trees are not identical.
            if (node1 == null && node2 == null) {
                continue;
            }
            if (node1 == null || node2 == null || node1.data != node2.data) {
                return false;
            }

            // Add the left and right children of both nodes to their respective queues.
            queue1.offer(node1.left);
            queue1.offer(node1.right);
            queue2.offer(node2.left);
            queue2.offer(node2.right);
        }

        // If both queues are empty, the trees are identical.
        return queue1.isEmpty() && queue2.isEmpty();
    }

    public static void main(String[] args) {
        SameTree s = new SameTree();
        TreeNode p=s.createBinaryTree1();
        TreeNode q=s.createBinaryTree2();
        boolean res=s.isSameTree(p,q);
        System.out.println("Tree's are identical----" +res);
    }

}
