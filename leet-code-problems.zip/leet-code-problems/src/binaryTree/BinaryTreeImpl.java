package binaryTree;

import java.util.*;

public class BinaryTreeImpl {
    private TreeNode root;

    private class TreeNode{
        private int data;
        private TreeNode left;
        private TreeNode right;
       public TreeNode(int data){
           this.data = data;

        }
    }

    public void preOrder(TreeNode root){
        if(root==null){
            return;
        }
        System.out.println(root.data + " ");
        preOrder(root.left);
        preOrder(root.right);
    }

    public  List<Integer> preorderIterativeTraversal(TreeNode root){
        List<Integer> list = new ArrayList<>();

        if(root ==null){
            return list;
        }
        Stack<TreeNode> stack = new Stack<>();
            stack.push(root);

        while(!stack.isEmpty()){
            TreeNode temp = stack.pop();
            list.add(temp.data);
            if(temp.right!=null){
                stack.push(temp.right);
            }
            if(temp.left!=null){
                stack.push(temp.left);
            }
        }
        return list;
    }

    public  List<Integer> inorderIterativeTraversal(TreeNode root){
        List<Integer> list = new ArrayList<>();

        if(root ==null){
            return list;
        }
        Stack<TreeNode> stack = new Stack<>();
            TreeNode temp = root;
            while(!stack.isEmpty() || temp!=null){
                if(temp!=null){
                    stack.push(temp);
                    temp = temp.left;
                }else{
                  temp=  stack.pop();
                  list.add(temp.data);
                  temp = temp.right;

                }

            }

return list;
    }


    public List<Integer> postOrderIterative2(TreeNode root){
        List<Integer> list = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        TreeNode p = root;
        while(p!=null  || !stack.isEmpty()){
            if(p!=null){
                list.add(p.data);
                stack.push(p);
                p = p.right;

            }else{
                p=stack.pop();
                p =p.left;
            }
        }
        Collections.reverse(list);
        return list;
    }

    public List<Integer> postOrderIterative(TreeNode root){
        List<Integer> postList = new ArrayList<>();
        if(root == null){
            return postList;
        }
        Stack<TreeNode> stack = new Stack<>();
        TreeNode current = root;
        while(!stack.isEmpty() || current!=null){
            if(current!=null){
                stack.push(current);
                current = current.left;
            }else{
                TreeNode temp = stack.peek().right;
                if(temp==null){
                    temp=stack.pop();
                    postList.add(temp.data);
                    while(!stack.isEmpty() && temp==stack.peek().right){
                        temp = stack.pop();
                        postList.add(temp.data);

                    }
                }else{
                    current = temp;
                }

            }
        }
        return postList;
    }


    /*
    Leet code
     */
    public List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> res = new LinkedList<>();
        if (root == null) {
            return res;
        }
        LinkedList<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            LinkedList<Integer> curLevel = new LinkedList<>();
            for (int i = 0, size = queue.size(); i < size; i++) { // use only 1 queue with this kind of for loop
                TreeNode node = queue.remove();
                curLevel.add(node.data);
                if (node.left != null) {
                    queue.add(node.left);
                }
                if (node.right != null) {
                    queue.add(node.right);
                }
            }
            res.add(curLevel);
        }
        return res;
    }

    public List<List<Integer>> levelOrder2(TreeNode root) {
        List<List<Integer>> res = new LinkedList<>();
        if(root==null){
            return res;
        }
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        while(!queue.isEmpty()){
            List<Integer> currntList = new LinkedList<>();
            for (int i = 0, size = queue.size(); i < size; i++) {
                TreeNode temp = queue.poll();
                currntList.add(temp.data);
                if (temp.left != null) {
                    queue.offer(temp.left);
                }
                if (temp.right != null) {
                    queue.offer(temp.right);
                }
            }
            res.add(currntList);
        }
        return res;
    }

    public static int findMax(TreeNode root){
        if(root==null){
            return Integer.MIN_VALUE;
        }
        int result = root.data;
        int left= findMax(root.left);
        int right = findMax(root.right);
        if(left>result){
            result = left;
        }
        if(right>result){
            result = right;
        }
        return result;
    }

    public void createBinaryTree(){
        TreeNode first = new TreeNode(9);
        TreeNode second = new TreeNode(2);
        TreeNode third = new TreeNode(3);
        TreeNode fourth = new TreeNode(4);
        //TreeNode fifth = new TreeNode(5);
        root = first;// root---> first
        root.left = second;
        root.right = third; // second<--- first--->third

        second.left = fourth;
       // second.right = fifth;

        /*TreeNode first = new TreeNode(1);
        TreeNode second = null;

        TreeNode third = new TreeNode(2);
        TreeNode fourth = new TreeNode(3);

        root = first;// root---> first
        root.left = second;
        root.right = third; // second<--- first--->third

        root.right.left = fourth;*/
    }


    /*
    Leet code problem for preorder traversal
     */
    public List<Integer> preorderTraversal(TreeNode root) {
        List<Integer> list = new ArrayList<>();
        preorderTraversalHelper(list, root);
        return list;
    }

    /*
   Leet code problem for preorder traersal
    */
    private void preorderTraversalHelper(List<Integer> list, TreeNode root) {
        if (root != null) {
            list.add(root.data);
            preorderTraversalHelper(list, root.left);
            preorderTraversalHelper(list, root.right);
        }
    }

    public List<Integer> inorderTraversal(TreeNode root) {
        List<Integer> list = new ArrayList<>();
        inorderTraversalHelper(list,root);
        return list;
    }

    private void inorderTraversalHelper(List<Integer> list, TreeNode root) {
        if (root != null) {
            inorderTraversalHelper(list, root.left);
            list.add(root.data);
            inorderTraversalHelper(list, root.right);
        }
    }

    public List<Integer> postorderTraversal(TreeNode root) {
        List<Integer> list = new ArrayList<>();
        postorderTraversalHelper(list , root);
        return list;
    }

    private void postorderTraversalHelper(List<Integer> list, TreeNode root) {
        if (root != null) {
            postorderTraversalHelper(list, root.left);
            postorderTraversalHelper(list, root.right);
            list.add(root.data);
        }
    }

    public static int maxDepth(TreeNode root) {
     /*
      using recursive
      if(root==null){
            return 0;
        }
        int left = maxDepth(root.left);
        int right = maxDepth(root.right);
        return 1+Math.max(left,right);*/
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int height=0;
        while (!queue.isEmpty()){
            int size = queue.size();
            for(int i=0;i<size;i++){
                TreeNode temp = queue.poll();
                if(temp.left!=null){
                    queue.offer(temp.left);
                }
                if(temp.right!=null){
                    queue.offer(temp.right);
                }


            }
            height++;
        }

return height;

    }

    public static int minDepth(TreeNode root) {
     /*
      using recursive
      if(root==null){
            return 0;
        }
        int left = maxDepth(root.left);
        int right = maxDepth(root.right);
        return 1+Math.max(left,right);*/
        if(root == null){
            return 0;
        }
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int height=1;
        while (!queue.isEmpty()){
            int size = queue.size();
            for(int i=0;i<size;i++){
                TreeNode temp = queue.poll();
                if(temp.left == null && temp.right ==null)
                    return height;
                if(temp.left!=null){
                    queue.offer(temp.left);
                }
                if(temp.right!=null){
                    queue.offer(temp.right);
                }


            }
            height++;
        }

        return height;

    }

    public static void main(String[] args) {
        BinaryTreeImpl binaryTree = new BinaryTreeImpl();
        binaryTree.createBinaryTree();
       // binaryTree.preOrder(binaryTree.root);
        List<Integer> preList = binaryTree.preorderTraversal(binaryTree.root);
        System.out.println("Preorder traversal using recursion: "+ preList);
        List<Integer> preList2 = binaryTree.preorderIterativeTraversal(binaryTree.root);
        System.out.println("Preorder traversal using iterative: "+ preList2);

        List<Integer> inorderList = binaryTree.inorderTraversal(binaryTree.root);
        System.out.println("Inorder traversal using recursion: "+ inorderList);
        List<Integer> inorderList2 = binaryTree.inorderIterativeTraversal(binaryTree.root);
        System.out.println("Inorder traversal using iterative: "+ inorderList2);

        List<Integer> postOrderList = binaryTree.postorderTraversal(binaryTree.root);
        System.out.println("Postorder traversal using recursion: " + postOrderList);

        List<Integer> postOrderList2 = binaryTree.postOrderIterative2(binaryTree.root);
        System.out.println("Postorder traversal using iterative: " + postOrderList2);

        List<List<Integer>> levelList= binaryTree.levelOrder2(binaryTree.root);
        System.out.println("Level traversal using iterative: " + levelList);

        System.out.println("Maximum value of binary tree: " + findMax(binaryTree.root));

        System.out.println("Maximum depth of binary tree: " + maxDepth(binaryTree.root));
        System.out.println("Minimu depth of binary tree: " + minDepth(binaryTree.root));

    }
}
