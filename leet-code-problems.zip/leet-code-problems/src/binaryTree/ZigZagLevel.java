package binaryTree;

import java.util.*;

public class ZigZagLevel {

TreeNode root;
    private class TreeNode{
        private int data;
        private ZigZagLevel.TreeNode left;
        private ZigZagLevel.TreeNode right;
        public TreeNode(int data){
            this.data = data;

        }
    }


    public static void main(String[] args) {
ZigZagLevel z = new ZigZagLevel();
z.createBinaryTree();
List<List<Integer>> res=ZigZagLevel.zigzagLevelOrder(z.root);
        System.out.println("Zigzag level traversal : "+ res);

    }

    public  void createBinaryTree(){
        ZigZagLevel.TreeNode first = new ZigZagLevel.TreeNode(3);
        ZigZagLevel.TreeNode second = new ZigZagLevel.TreeNode(9);
        ZigZagLevel.TreeNode third = new ZigZagLevel.TreeNode(20);
        ZigZagLevel.TreeNode fourth = new ZigZagLevel.TreeNode(15);
        ZigZagLevel.TreeNode fifth = new ZigZagLevel.TreeNode(7);
        //TreeNode fifth = new TreeNode(5);
        root = first;// root---> first
        root.left = second;
        root.right = third; // second<--- first--->third

        third.left = fourth;
       third.right = fifth;
    }

    public static List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> list = new ArrayList<>();
        if(root==null){
            return list;
        }
        Queue<TreeNode> q = new LinkedList<TreeNode>();
        q.add(root);
        while(!q.isEmpty()){
            int size = q.size();
            List<Integer> l= new ArrayList<>();

            for(int i=0;i<size;i++ ){
               TreeNode current= q.poll();
               l.add(current.data);
               if(current.left!=null){
                   q.add(current.left);
               }
               if(current.right!=null){
                   q.add(current.right);
               }
            }
            list.add(l);
        }

        for(int i=0;i<list.size();i++){
            if(i%2!=0){
                Collections.reverse(list.get(i));
            }
        }
        return list;

    }
}
